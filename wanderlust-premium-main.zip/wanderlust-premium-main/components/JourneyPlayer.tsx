
import React, { useState, useMemo } from 'react';
import { RouteModel, RoutePoint } from '../types';
import { 
  X, ChevronLeft, ChevronRight, Play, Info, 
  Volume2, Maximize2, Map as MapIcon, 
  Layers, MessageCircle, ArrowLeft
} from 'lucide-react';
import { ScenicMap } from './ScenicMap';

interface JourneyPlayerProps {
  route: RouteModel;
  onClose: () => void;
}

export const JourneyPlayer: React.FC<JourneyPlayerProps> = ({ route, onClose }) => {
  const [currentPointIndex, setCurrentPointIndex] = useState(0);
  const [showFullMap, setShowFullMap] = useState(false);
  const [activeHotspot, setActiveHotspot] = useState<RoutePoint | null>(null);

  const parentPoints = useMemo(() => route.points.filter(p => !p.parentId), [route.points]);
  const currentParent = parentPoints[currentPointIndex];
  
  const hotspots = useMemo(() => 
    route.points.filter(p => p.parentId === currentParent?.id),
  [route.points, currentParent]);

  const handleNext = () => {
    if (currentPointIndex < parentPoints.length - 1) {
      setCurrentPointIndex(currentPointIndex + 1);
      setActiveHotspot(null);
    }
  };

  const handlePrev = () => {
    if (currentPointIndex > 0) {
      setCurrentPointIndex(currentPointIndex - 1);
      setActiveHotspot(null);
    }
  };

  return (
    <div className="fixed inset-0 z-[100] bg-slate-900 flex flex-col md:flex-row animate-fade-in overflow-hidden">
      
      {/* Botón Cerrar / Volver */}
      <button 
        onClick={onClose}
        className="absolute top-6 left-6 z-[110] w-12 h-12 bg-white/10 backdrop-blur-xl border border-white/20 rounded-2xl flex items-center justify-center text-white hover:bg-white hover:text-slate-900 transition-all shadow-2xl"
      >
        <ArrowLeft className="w-6 h-6" />
      </button>

      {/* VISTA PRINCIPAL: ESCENA ILUSTRADA / SNAPSHOT */}
      <div className="relative flex-grow h-full bg-black overflow-hidden group">
        <div 
          className="absolute inset-0 bg-cover bg-center transition-transform duration-[2000ms] scale-105"
          style={{ backgroundImage: `url(${currentParent?.snapshotUrl || route.thumbnail})` }}
        >
          <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-transparent to-black/60" />
        </div>

        {/* Hotspots sobre la escena */}
        {hotspots.map((hp) => (
          <button
            key={hp.id}
            onClick={() => setActiveHotspot(hp)}
            className="absolute z-20 transform -translate-x-1/2 -translate-y-1/2 group/hp transition-all"
            style={{ left: `${hp.streetViewTarget?.x}%`, top: `${hp.streetViewTarget?.y}%` }}
          >
            <div className={`w-10 h-10 rounded-full border-4 border-white/50 backdrop-blur-md flex items-center justify-center shadow-glow-sm transition-all group-hover/hp:scale-125 ${activeHotspot?.id === hp.id ? 'bg-brand-500 scale-125' : 'bg-white/20'}`}>
              <Info className="w-5 h-5 text-white" />
            </div>
            <span className="absolute top-full left-1/2 -translate-x-1/2 mt-2 bg-black/60 backdrop-blur-md text-white text-[10px] font-bold px-3 py-1 rounded-full opacity-0 group-hover/hp:opacity-100 transition-opacity whitespace-nowrap">
              {hp.title}
            </span>
          </button>
        ))}

        {/* Título de la Parada Actual */}
        <div className="absolute top-20 left-1/2 -translate-x-1/2 text-center w-full px-6 pointer-events-none">
          <span className="text-brand-400 font-black text-[10px] uppercase tracking-[0.3em] mb-2 block animate-fade-in-up">Parada {currentPointIndex + 1} de {parentPoints.length}</span>
          <h2 className="text-3xl md:text-5xl font-black text-white tracking-tighter drop-shadow-2xl animate-fade-in-up">{currentParent?.title}</h2>
        </div>

        {/* Panel de Información del Hotspot (Modal Lateral) */}
        {activeHotspot && (
          <div className="absolute right-0 top-0 bottom-0 w-full md:w-[400px] z-50 animate-fade-in-left">
            <div className="h-full bg-white/95 backdrop-blur-2xl shadow-2xl p-8 flex flex-col">
              <div className="flex justify-between items-start mb-8">
                <div className="flex items-center gap-3">
                   <div className="w-10 h-10 bg-brand-100 text-brand-600 rounded-xl flex items-center justify-center">
                      <Layers className="w-5 h-5" />
                   </div>
                   <h3 className="font-black text-xl text-slate-900 tracking-tight">{activeHotspot.title}</h3>
                </div>
                <button onClick={() => setActiveHotspot(null)} className="p-2 hover:bg-slate-100 rounded-xl transition-colors text-slate-400"><X className="w-6 h-6" /></button>
              </div>
              
              <div className="flex-grow overflow-y-auto space-y-6 custom-scrollbar pr-2">
                 {activeHotspot.mediaUrl && activeHotspot.mediaType === 'image' && (
                   <img src={activeHotspot.mediaUrl} className="w-full aspect-video object-cover rounded-2xl shadow-lg" alt="" />
                 )}
                 <p className="text-slate-600 leading-relaxed text-lg font-medium">{activeHotspot.description}</p>
                 
                 <div className="bg-slate-50 p-6 rounded-3xl border border-slate-100 flex items-center gap-4">
                    <button className="w-12 h-12 bg-brand-600 text-white rounded-2xl flex items-center justify-center shadow-lg hover:scale-105 transition-all">
                       <Volume2 className="w-5 h-5" />
                    </button>
                    <div>
                       <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Narrador AI</span>
                       <p className="text-sm font-bold text-slate-900">Escuchar audio guía</p>
                    </div>
                 </div>
              </div>
              
              <button onClick={() => setActiveHotspot(null)} className="mt-8 w-full bg-slate-900 text-white py-4 rounded-2xl font-bold shadow-xl">Cerrar Detalle</button>
            </div>
          </div>
        )}
      </div>

      {/* BARRA LATERAL / INFERIOR: CONTROLES Y MAPA MINI */}
      <div className="w-full md:w-[380px] bg-white flex flex-col shrink-0 z-40 border-l border-slate-100">
        
        {/* Mapa de Progresión (Capa Superior) */}
        <div className={`relative transition-all duration-500 overflow-hidden ${showFullMap ? 'h-full' : 'h-48'}`}>
           <ScenicMap 
              points={parentPoints}
              baseLocation={route.location}
              activePointId={currentParent?.id}
              className="w-full h-full"
              cityImage={route.thumbnail}
           />
           <button 
            onClick={() => setShowFullMap(!showFullMap)}
            className="absolute bottom-4 right-4 bg-white/90 backdrop-blur-md p-2 rounded-xl shadow-lg border border-slate-100 text-slate-800"
           >
             {showFullMap ? <X className="w-5 h-5" /> : <Maximize2 className="w-5 h-5" />}
           </button>
           {!showFullMap && (
             <div className="absolute top-4 left-4 bg-slate-900/80 backdrop-blur-md text-white text-[10px] font-bold px-3 py-1 rounded-full uppercase tracking-widest border border-white/10">
               Tu Ubicación
             </div>
           )}
        </div>

        {/* Lista de Pasos y Navegación */}
        {!showFullMap && (
          <div className="flex-grow flex flex-col p-6">
            <div className="flex-grow overflow-y-auto space-y-4 mb-6 custom-scrollbar pr-2">
              {parentPoints.map((p, idx) => (
                <button 
                  key={p.id}
                  onClick={() => setCurrentPointIndex(idx)}
                  className={`w-full flex items-center gap-4 p-4 rounded-2xl transition-all border text-left
                    ${currentPointIndex === idx 
                      ? 'bg-brand-50 border-brand-200 shadow-sm' 
                      : 'bg-white border-transparent hover:bg-slate-50'}
                  `}
                >
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center font-black text-sm shrink-0
                    ${currentPointIndex === idx ? 'bg-brand-600 text-white shadow-lg' : 'bg-slate-100 text-slate-400'}
                  `}>
                    {idx + 1}
                  </div>
                  <div className="min-w-0">
                    <h4 className={`font-bold text-sm truncate ${currentPointIndex === idx ? 'text-slate-900' : 'text-slate-500'}`}>{p.title}</h4>
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{p.durationMin} min • {p.mediaType !== 'none' ? 'Multimedia' : 'Vista'}</span>
                  </div>
                </button>
              ))}
            </div>

            {/* Controles de Reproducción */}
            <div className="grid grid-cols-2 gap-4">
              <button 
                onClick={handlePrev}
                disabled={currentPointIndex === 0}
                className="flex items-center justify-center gap-2 py-4 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-2xl font-bold transition-all disabled:opacity-30"
              >
                <ChevronLeft className="w-5 h-5" /> Anterior
              </button>
              <button 
                onClick={handleNext}
                disabled={currentPointIndex === parentPoints.length - 1}
                className="flex items-center justify-center gap-2 py-4 bg-brand-600 hover:bg-brand-700 text-white rounded-2xl font-bold shadow-lg shadow-brand-200 transition-all disabled:opacity-30"
              >
                Siguiente <ChevronRight className="w-5 h-5" />
              </button>
            </div>
          </div>
        )}
      </div>

      <style>{`
        @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
        @keyframes fadeInLeft { from { opacity: 0; transform: translateX(20px); } to { opacity: 1; transform: translateX(0); } }
        .animate-fade-in { animation: fadeIn 0.5s ease-out forwards; }
        .animate-fade-in-left { animation: fadeInLeft 0.5s cubic-bezier(0.16, 1, 0.3, 1) forwards; }
      `}</style>
    </div>
  );
};
