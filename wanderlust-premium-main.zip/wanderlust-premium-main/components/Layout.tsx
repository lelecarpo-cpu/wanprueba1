
import React, { useEffect, useState } from 'react';
import { Map, PlusCircle, Menu, X, ShoppingCart, Globe, ChevronDown, Home, Compass, User, Search, LogIn, Command } from 'lucide-react';
import { AVAILABLE_LOCATIONS } from '../constants';
import { useLocation, useNavigate } from 'react-router-dom';
import { GeoLocation } from '../types';
import { useAuth } from '../contexts/AuthContext';
import { SearchOverlay } from './SearchOverlay';

interface LayoutProps {
  children: React.ReactNode;
  userLocation: GeoLocation;
  onLocationChange: (loc: GeoLocation) => void;
  cartCount: number;
}

export const Layout: React.FC<LayoutProps> = ({ children, userLocation, onLocationChange, cartCount }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();
  const { user } = useAuth();

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setIsSearchOpen(true);
      }
    };
    window.addEventListener('keydown', handleKeyDown);

    return () => {
      window.removeEventListener('scroll', handleScroll);
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, []);

  const isActiveDesktop = (path: string) => 
    location.pathname === path 
      ? 'text-slate-900 bg-white shadow-md font-semibold' 
      : 'text-slate-500 hover:text-[#00796B] hover:bg-white/50';

  return (
    <div className="min-h-screen flex flex-col bg-[#F0F4F8] font-sans relative overflow-x-hidden">
      <SearchOverlay isOpen={isSearchOpen} onClose={() => setIsSearchOpen(false)} />
      
      {/* Decorative Grid Background */}
      <div className="fixed inset-0 z-0 pointer-events-none" style={{ backgroundImage: 'radial-gradient(#80CBC4 1px, transparent 1px)', backgroundSize: '60px 60px', opacity: 0.1 }}></div>

      <header className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 px-4 sm:px-6 lg:px-8 ${scrolled ? 'py-2' : 'py-4'}`}>
        <div className={`max-w-7xl mx-auto rounded-[2rem] transition-all duration-500 border ${scrolled ? 'bg-white/90 backdrop-blur-xl border-white/40 shadow-xl px-4 py-2' : 'bg-transparent border-transparent px-0'}`}>
          <div className="flex justify-between items-center">
            
            <div className="flex items-center cursor-pointer group" onClick={() => navigate('/')}>
              <div className="w-10 h-10 bg-[#EF5350] rounded-2xl flex items-center justify-center mr-3 shadow-lg shadow-[#EF5350]/20 group-hover:scale-105 transition-all">
                <Map className="text-white w-5 h-5" />
              </div>
              <span className="text-2xl font-bold tracking-tighter text-slate-800">Wander<span className="text-[#26A69A]">lust</span></span>
            </div>

            <nav className="hidden md:flex items-center bg-white/60 backdrop-blur-sm rounded-full p-1 border border-white/50 mx-4">
              <button onClick={() => navigate('/')} className={`px-6 py-2 rounded-full text-sm transition-all ${isActiveDesktop('/')}`}>Inicio</button>
              <button onClick={() => navigate('/categories')} className={`px-6 py-2 rounded-full text-sm transition-all ${isActiveDesktop('/categories')}`}>Explorar</button>
              
              <button 
                onClick={() => setIsSearchOpen(true)}
                className="flex items-center gap-2 px-6 py-2 rounded-full text-sm text-slate-400 hover:text-slate-600 transition-all"
              >
                <Search className="w-4 h-4" />
                <span className="hidden lg:inline">Buscar...</span>
                <kbd className="hidden lg:inline-flex h-5 items-center gap-1 rounded border border-slate-200 bg-white px-1.5 font-mono text-[10px] font-medium text-slate-400">
                   <Command className="w-2.5 h-2.5" />K
                </kbd>
              </button>
            </nav>

            <div className="flex items-center gap-2">
              <div className="relative group">
                <button className="flex items-center space-x-2 text-xs font-semibold text-slate-700 bg-white/80 px-4 py-2.5 rounded-full border border-slate-200/50 hover:bg-white transition-all shadow-sm">
                  <Globe className="w-4 h-4 text-[#26A69A]" />
                  <span className="hidden sm:inline">{userLocation.name.split(',')[0]}</span>
                  <ChevronDown className="w-3 h-3 opacity-50" />
                </button>
                <div className="absolute right-0 top-full mt-3 w-64 bg-white rounded-[2rem] shadow-2xl border border-slate-100 hidden group-hover:block p-2 animate-fade-in-up">
                  {AVAILABLE_LOCATIONS.map(loc => (
                    <button key={loc.name} onClick={() => onLocationChange(loc)} className="flex items-center w-full px-4 py-3 text-sm text-slate-700 hover:bg-[#E0F2F1] rounded-2xl transition-all">
                      <span className={`w-2 h-2 rounded-full mr-3 ${loc.name === userLocation.name ? 'bg-[#EF5350]' : 'bg-slate-300'}`}></span>
                      {loc.name}
                    </button>
                  ))}
                </div>
              </div>

              <div className="hidden md:flex items-center gap-3">
                <button onClick={() => navigate('/cart')} className="relative w-10 h-10 flex items-center justify-center bg-white/80 hover:bg-white border border-slate-200/50 rounded-full text-slate-600 transition-all shadow-sm">
                  <ShoppingCart className="w-5 h-5" />
                  {cartCount > 0 && <span className="absolute -top-1 -right-1 min-w-[18px] h-[18px] bg-[#EF5350] text-white text-[10px] font-bold rounded-full flex items-center justify-center border-2 border-white">{cartCount}</span>}
                </button>
                {user ? (
                   <button onClick={() => navigate('/profile')} className="w-10 h-10 rounded-full border-2 border-white shadow-md bg-[#B2DFDB] flex items-center justify-center text-[#00796B] font-bold overflow-hidden">
                      {user.email?.substring(0,2).toUpperCase()}
                   </button>
                ) : (
                  <button onClick={() => navigate('/auth')} className="bg-slate-800 text-white px-5 py-2.5 rounded-full text-sm font-bold shadow-lg hover:bg-slate-900 transition-colors">Entrar</button>
                )}
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="h-24 md:h-28"></div>
      <main className="flex-grow pb-20 md:pb-0">{children}</main>
    </div>
  );
};
