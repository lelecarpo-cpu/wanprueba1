
import React, { useEffect } from 'react';

interface SEOProps {
  title: string;
  description: string;
  schema?: object;
  breadcrumbs?: { name: string, item: string }[];
}

export const SEOHelmet: React.FC<SEOProps> = ({ title, description, schema, breadcrumbs }) => {
  useEffect(() => {
    document.title = `${title} | Wanderlust`;
    
    // Meta Description
    let metaDescription = document.querySelector('meta[name="description"]');
    if (!metaDescription) {
      metaDescription = document.createElement('meta');
      metaDescription.setAttribute('name', 'description');
      document.head.appendChild(metaDescription);
    }
    metaDescription.setAttribute('content', description);

    // Schema JSON-LD
    const scriptId = 'json-ld-schema';
    let scriptTag = document.getElementById(scriptId);
    
    const schemas = [];
    if (schema) schemas.push(schema);
    if (breadcrumbs) {
      schemas.push({
        "@context": "https://schema.org",
        "@type": "BreadcrumbList",
        "itemListElement": breadcrumbs.map((crumb, index) => ({
          "@type": "ListItem",
          "position": index + 1,
          "name": crumb.name,
          "item": `https://wanderlust.app${crumb.item}`
        }))
      });
    }

    if (schemas.length > 0) {
      if (!scriptTag) {
        scriptTag = document.createElement('script');
        scriptTag.id = scriptId;
        scriptTag.setAttribute('type', 'application/ld+json');
        document.head.appendChild(scriptTag);
      }
      scriptTag.textContent = JSON.stringify(schemas);
    }

  }, [title, description, schema, breadcrumbs]);

  return null;
};
