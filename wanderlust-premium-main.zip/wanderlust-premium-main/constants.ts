

import { CategoryType, RouteModel, Creator, GeoLocation, RoutePoint } from './types';

export interface CityLocation extends GeoLocation {
  shapePath: string; // SVG path en coordenadas 0-100
  bounds: { // Límites geográficos reales para la proyección
    minLat: number;
    maxLat: number;
    minLng: number;
    maxLng: number;
  };
}

export const AVAILABLE_LOCATIONS: CityLocation[] = [
  { 
    lat: 40.4168, 
    lng: -3.7038, 
    name: 'Madrid, España',
    // Bounding box de la Comunidad de Madrid Completa
    // N: 41.17 (Somosierra), S: 39.88 (Aranjuez), W: -4.58 (Cenicientos), E: -3.05 (Estremera)
    bounds: {
        minLat: 39.8800,
        maxLat: 41.1700,
        minLng: -4.5800,
        maxLng: -3.0500
    },
    // Silueta detallada de la Comunidad de Madrid
    shapePath: "M48.5,1.5 C52,3.5 58,9 62,12 C66,15 75,19 78,21 C81,23 90,28 92,31 C94,34 98,45 98,49 C98,53 94,62 91,66 C88,70 78,78 76,80 C74,82 61,94 59,96 C57,98 52,99 49,97 C46,95 40,89 37,86 C34,83 22,75 19,72 C16,69 4,58 3,55 C2,52 2,44 4,40 C6,36 15,26 18,23 C21,20 31,12 34,10 C37,8 45,1 48.5,1.5 Z"
  },
  { 
    lat: 19.4326, 
    lng: -99.1332, 
    name: 'Ciudad de México, MX',
    bounds: {
        minLat: 19.3900,
        maxLat: 19.4700,
        minLng: -99.1800,
        maxLng: -99.1000
    },
    shapePath: "M25,20 L75,20 L90,50 L75,85 L25,85 L10,50 Z"
  },
  { 
    lat: 4.6097, 
    lng: -74.0817, 
    name: 'Bogotá, Colombia',
    bounds: {
        minLat: 4.5500,
        maxLat: 4.6500,
        minLng: -74.1200,
        maxLng: -74.0400
    },
    shapePath: "M30,15 L70,15 L85,45 L75,85 L45,95 L20,65 Z"
  },
];

export const CATEGORY_METADATA: Record<CategoryType, { icon: string, imageKeyword: string, desc: string }> = {
  [CategoryType.YINCANAS]: { icon: 'Flag', imageKeyword: 'puzzle', desc: 'Resuelve acertijos y desafíos urbanos.' },
  [CategoryType.TURISMO]: { icon: 'Map', imageKeyword: 'city', desc: 'Los puntos imprescindibles de la ciudad.' },
  [CategoryType.NATURALEZA]: { icon: 'Mountain', imageKeyword: 'forest', desc: 'Senderos, parques y aire puro.' },
  [CategoryType.FITNESS]: { icon: 'Activity', imageKeyword: 'runner', desc: 'Rutas optimizadas para deporte y running.' },
  [CategoryType.GASTRONOMIA]: { icon: 'Utensils', imageKeyword: 'food', desc: 'Un viaje a través de los sabores locales.' },
  [CategoryType.FOTOGRAFIA]: { icon: 'Camera', imageKeyword: 'view', desc: 'Los mejores spots para capturar momentos.' },
  [CategoryType.ARTE]: { icon: 'Palette', imageKeyword: 'museum', desc: 'Galerías, murales y expresiones culturales.' },
  [CategoryType.ARQUITECTURA]: { icon: 'Building', imageKeyword: 'architecture', desc: 'Edificios que cuentan historias únicas.' },
  [CategoryType.HISTORIA]: { icon: 'Scroll', imageKeyword: 'ruins', desc: 'Viaja al pasado por rincones históricos.' },
  [CategoryType.VIDA_NOCTURNA]: { icon: 'Moon', imageKeyword: 'nightlife', desc: 'Bares, clubs y luces de la ciudad.' },
  [CategoryType.AVENTURA]: { icon: 'Compass', imageKeyword: 'extreme', desc: 'Adrenalina y retos para los más valientes.' },
  [CategoryType.OCULTOS]: { icon: 'Key', imageKeyword: 'secret', desc: 'Joyas escondidas y lugares poco conocidos.' },
  [CategoryType.ESPIRITUAL]: { icon: 'Sun', imageKeyword: 'meditation', desc: 'Puntos de paz, meditación y wellness.' },
};

export const getCategoryImage = (category: CategoryType, index: number): string => {
  const keyword = CATEGORY_METADATA[category]?.imageKeyword || 'travel';
  return `https://picsum.photos/seed/${category}-${index}/800/600?${keyword}`;
};

export const MOCK_CREATOR: Creator = {
  id: 'c1',
  name: 'Lele Carpo',
  avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=LeleCarpo',
  rating: 5.0,
  reviewCount: 342,
  routesCount: 130,
  bio: 'Explorador urbano apasionado por la historia y la fotografía. Mis rutas están diseñadas para descubrir lo que no sale en las guías.',
  badges: ['Verificado', 'Creador Top', 'Guía Local']
};

export const generateMockRoutes = (baseLocation: GeoLocation): RouteModel[] => {
  const routes: RouteModel[] = [];
  const categories = Object.values(CategoryType);
  const adjectives = ['Esencial', 'Secreta', 'Mágica', 'Oculta', 'VIP', 'Ancestral', 'Urbana', 'Expresa', 'De Lujo', 'Bohemia'];
  const nouns = ['Aventura', 'Ruta', 'Experiencia', 'Travesía', 'Escapada', 'Odisea', 'Paseo'];

  // Aumentamos la dispersión para que ocupe más espacio en el mapa de la comunidad
  // 0.3 grados aprox 30-40km, cubre gran parte de la comunidad de Madrid
  const spreadFactor = baseLocation.name.includes('Madrid') ? 0.35 : 0.04; 

  categories.forEach((cat, catIdx) => {
    for (let i = 0; i < 5; i++) {
      const adj = adjectives[(catIdx + i) % adjectives.length];
      const noun = nouns[(i) % nouns.length];
      const routeId = `r-${catIdx}-${i}`;
      
      // Generar puntos dispersos
      const points: RoutePoint[] = Array.from({ length: 4 }).map((_, pIdx) => {
        const latOffset = (Math.random() - 0.5) * spreadFactor; 
        const lngOffset = (Math.random() - 0.5) * spreadFactor;
        
        return {
          id: `${routeId}-p${pIdx}`,
          lat: baseLocation.lat + latOffset,
          lng: baseLocation.lng + lngOffset,
          title: `Punto de interés ${pIdx + 1}`,
          description: `Descubre los secretos que guarda este lugar emblemático de la región.`,
          mediaType: 'none',
          durationMin: 15 + Math.floor(Math.random() * 20)
        };
      });

      routes.push({
        id: routeId,
        title: `${noun} ${cat.split(' ')[0]} ${adj}`,
        slug: `${routeId}-slug-${i}`,
        description: `Disfruta de una ${noun.toLowerCase()} única por los rincones más ${adj.toLowerCase()}s de la región.`,
        category: cat,
        price: i === 0 ? 0 : (14.99 + (i * 4.99)), 
        currency: 'USD',
        rating: 4.2 + Math.random() * 0.8,
        reviews: 10 + Math.floor(Math.random() * 500),
        difficulty: i % 3 === 0 ? 'Fácil' : i % 3 === 1 ? 'Moderado' : 'Difícil',
        distanceKm: 2.5 + (i * 1.2),
        durationMin: 60 + (i * 30),
        thumbnail: `https://picsum.photos/seed/${routeId}/800/600`,
        location: baseLocation,
        creator: MOCK_CREATOR,
        points: points,
        tags: i === 0 ? ['Popular'] : ['Premium'],
        status: 'published'
      });
    }
  });

  return routes;
};