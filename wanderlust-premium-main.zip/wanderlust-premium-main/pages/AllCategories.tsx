import React from 'react';
import { useNavigate } from 'react-router-dom';
import { CATEGORY_METADATA, getCategoryImage } from '../constants';
import { SEOHelmet } from '../components/SEOHelmet';
import { ArrowRight } from 'lucide-react';

export const AllCategories: React.FC = () => {
  const navigate = useNavigate();

  return (
    <>
      <SEOHelmet 
        title="Todas las Categorías" 
        description="Explora rutas por categoría: turismo, naturaleza, fitness, gastronomía, y más." 
        breadcrumbs={[{ name: 'Categorías', item: '/categories' }]}
      />

      <div className="bg-slate-50 min-h-screen py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="text-center mb-16">
            <h1 className="text-4xl md:text-5xl font-bold text-slate-900 mb-6">Explora por Categoría</h1>
            <p className="text-xl text-slate-600 max-w-3xl mx-auto">
              Desde caminatas relajantes hasta aventuras extremas. Encuentra la experiencia perfecta que se adapte a tu estado de ánimo y objetivos.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {Object.entries(CATEGORY_METADATA).map(([key, meta], index) => (
              <div 
                key={key}
                onClick={() => navigate(`/category/${encodeURIComponent(key)}`)}
                className="group cursor-pointer bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-2xl transition-all duration-300 border border-slate-100 flex flex-col"
              >
                <div className="h-48 overflow-hidden relative">
                  <div className="absolute inset-0 bg-black/20 group-hover:bg-black/10 transition-colors z-10" />
                  <img 
                    src={getCategoryImage(key as any, index)} 
                    alt={key} 
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                  />
                  <div className="absolute top-4 left-4 z-20 bg-white/90 backdrop-blur p-2 rounded-lg shadow-lg">
                     {/* Placeholder Icon */}
                     <span className="text-xl">📍</span>
                  </div>
                </div>
                
                <div className="p-8 flex-grow flex flex-col">
                  <h2 className="text-2xl font-bold text-slate-900 mb-2 group-hover:text-brand-600 transition-colors">{key}</h2>
                  <p className="text-slate-500 mb-6 flex-grow">{meta.desc}</p>
                  
                  <div className="flex items-center text-brand-600 font-bold text-sm uppercase tracking-wide group-hover:underline">
                    Ver Rutas <ArrowRight className="ml-2 w-4 h-4" />
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* SEO Content Section */}
          <div className="mt-24 bg-white rounded-3xl p-10 shadow-sm border border-slate-100">
             <h2 className="text-2xl font-bold text-slate-900 mb-6">¿Por qué elegir rutas digitales?</h2>
             <div className="grid md:grid-cols-3 gap-8 text-slate-600">
                <div>
                   <h3 className="font-bold text-slate-800 mb-2">Expertos Locales</h3>
                   <p className="text-sm">Cada ruta está diseñada por personas que conocen la ciudad como la palma de su mano. Descubre secretos que no están en las guías turísticas.</p>
                </div>
                <div>
                   <h3 className="font-bold text-slate-800 mb-2">A tu propio ritmo</h3>
                   <p className="text-sm">Sin horarios fijos ni grupos grandes. Empieza cuando quieras, detente a tomar un café y continúa cuando estés listo.</p>
                </div>
                <div>
                   <h3 className="font-bold text-slate-800 mb-2">Contenido Multimedia</h3>
                   <p className="text-sm">Disfruta de audio guías, videos y fotos históricas en cada punto de interés para una experiencia inmersiva completa.</p>
                </div>
             </div>
          </div>

        </div>
      </div>
    </>
  );
};