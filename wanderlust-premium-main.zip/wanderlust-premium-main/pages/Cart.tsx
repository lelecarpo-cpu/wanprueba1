
import React, { useState } from 'react';
import { RouteModel } from '../types';
import { SEOHelmet } from '../components/SEOHelmet';
import { Trash2, CreditCard, Lock, CheckCircle, ArrowRight, ShieldCheck } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface CartProps {
  items: RouteModel[];
  onRemoveItem: (id: string) => void;
  onClearCart: () => void;
}

type CheckoutStep = 'cart' | 'payment' | 'success';

export const Cart: React.FC<CartProps> = ({ items, onRemoveItem, onClearCart }) => {
  const [step, setStep] = useState<CheckoutStep>('cart');
  const [isProcessing, setIsProcessing] = useState(false);
  const navigate = useNavigate();

  const total = items.reduce((acc, item) => acc + item.price, 0);
  const formatPrice = (p: number) => p === 0 ? 'Gratis' : `$${p.toFixed(2)}`;

  const handlePayment = () => {
    setIsProcessing(true);
    setTimeout(() => {
      setIsProcessing(false);
      setStep('success');
      onClearCart();
    }, 2000);
  };

  if (step === 'success') {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
        <div className="bg-white max-w-md w-full rounded-[2.5rem] shadow-2xl p-10 text-center animate-fade-in border border-slate-100">
           <div className="w-20 h-20 bg-green-100 rounded-2xl flex items-center justify-center mx-auto mb-6">
              <CheckCircle className="w-10 h-10 text-green-600" />
           </div>
           <h1 className="text-3xl font-black text-slate-900 mb-2 tracking-tighter">¡Pago Exitoso!</h1>
           <p className="text-slate-500 mb-8 leading-relaxed font-medium">Tus rutas han sido añadidas a tu biblioteca personal y están listas para tu próxima aventura.</p>
           
           <div className="space-y-3">
              <button onClick={() => navigate('/profile')} className="w-full bg-brand-600 hover:bg-brand-700 text-white py-4 rounded-2xl font-black shadow-lg shadow-brand-200 transition-all">
                Ver Mis Rutas
              </button>
              <button onClick={() => navigate('/')} className="w-full bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 py-4 rounded-2xl font-black transition-all">
                Seguir Explorando
              </button>
           </div>
        </div>
      </div>
    );
  }

  return (
    <>
      <SEOHelmet title="Carrito de Compras" description="Finaliza tu compra segura en Wanderlust." />

      <div className="min-h-screen bg-slate-50 py-12">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <h1 className="text-3xl font-black text-slate-900 mb-8 tracking-tighter">
            {step === 'cart' ? 'Tu Carrito' : 'Finalizar Compra'}
          </h1>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
            
            <div className="lg:col-span-2">
               {step === 'cart' ? (
                 <div className="bg-white rounded-[2rem] shadow-sm border border-slate-100 overflow-hidden">
                    {items.length === 0 ? (
                       <div className="text-center py-24 px-4">
                          <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4">
                             <Trash2 className="w-6 h-6 text-slate-300" />
                          </div>
                          <p className="text-slate-400 font-bold mb-6">Tu carrito está vacío en este momento.</p>
                          <button onClick={() => navigate('/')} className="bg-brand-600 text-white px-8 py-3 rounded-xl font-bold hover:shadow-lg transition-all">Ir al Marketplace</button>
                       </div>
                    ) : (
                       <div className="divide-y divide-slate-100">
                          {items.map(item => (
                             <div key={item.id} className="p-8 flex flex-col sm:flex-row items-center gap-8 group">
                                <img src={item.thumbnail} className="w-24 h-24 rounded-2xl object-cover shadow-md group-hover:scale-105 transition-transform" alt={item.title} />
                                <div className="flex-grow text-center sm:text-left">
                                   <h3 className="font-black text-xl text-slate-900 tracking-tight">{item.title}</h3>
                                   <p className="text-xs font-bold text-slate-500 mb-3 uppercase tracking-wider">{item.category}</p>
                                   <div className="flex items-center justify-center sm:justify-start gap-2 text-[10px] font-black uppercase text-green-600 bg-green-50 inline-flex px-3 py-1 rounded-full">
                                      <CheckCircle className="w-3.5 h-3.5" /> Acceso de por vida
                                   </div>
                                </div>
                                <div className="flex flex-col items-center sm:items-end gap-3">
                                   <span className="text-2xl font-black text-slate-900">{formatPrice(item.price)}</span>
                                   <button 
                                      onClick={() => onRemoveItem(item.id)}
                                      className="text-slate-300 hover:text-red-500 p-2 transition-colors"
                                      aria-label="Eliminar"
                                   >
                                      <Trash2 className="w-5 h-5" />
                                   </button>
                                </div>
                             </div>
                          ))}
                       </div>
                    )}
                 </div>
               ) : (
                 <div className="space-y-6">
                    <div className="bg-white rounded-[2rem] p-10 border border-slate-100 shadow-sm">
                       <h3 className="text-xl font-black text-slate-900 mb-8 flex items-center gap-3 tracking-tight">
                          <CreditCard className="w-6 h-6 text-brand-600" /> Detalles de Pago
                       </h3>
                       
                       <div className="space-y-6">
                          <div>
                             <label className="block text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2">Titular de la tarjeta</label>
                             <input type="text" placeholder="EJ. ALEX SMITH" className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-4 focus:ring-2 focus:ring-brand-500 outline-none font-bold" />
                          </div>
                          <div>
                             <label className="block text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2">Número de tarjeta</label>
                             <div className="relative">
                                <input type="text" placeholder="0000 0000 0000 0000" className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-4 focus:ring-2 focus:ring-brand-500 outline-none pl-12 font-bold" />
                                <CreditCard className="absolute left-4 top-4.5 w-5 h-5 text-slate-400" />
                             </div>
                          </div>
                          <div className="grid grid-cols-2 gap-6">
                             <div>
                                <label className="block text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2">Expiración</label>
                                <input type="text" placeholder="MM/AA" className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-4 focus:ring-2 focus:ring-brand-500 outline-none font-bold text-center" />
                             </div>
                             <div>
                                <label className="block text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2">CVC</label>
                                <input type="text" placeholder="123" className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-4 focus:ring-2 focus:ring-brand-500 outline-none font-bold text-center" />
                             </div>
                          </div>
                       </div>
                    </div>
                    
                    <button onClick={() => setStep('cart')} className="text-slate-400 hover:text-slate-900 text-xs font-black uppercase tracking-widest flex items-center gap-2 px-4 transition-all">
                       ← Volver al carrito
                    </button>
                 </div>
               )}
            </div>

            <div className="lg:col-span-1">
               <div className="bg-white rounded-[2rem] p-8 shadow-xl border border-slate-100 sticky top-28">
                  <h3 className="font-black text-xl text-slate-900 mb-8 tracking-tight">Resumen de Compra</h3>
                  
                  <div className="space-y-4 mb-8 text-sm font-bold text-slate-500">
                     <div className="flex justify-between">
                        <span className="uppercase tracking-wide text-[10px]">Subtotal ({items.length} items)</span>
                        <span className="text-slate-900">{formatPrice(total)}</span>
                     </div>
                     <div className="flex justify-between">
                        <span className="uppercase tracking-wide text-[10px]">Tasa de servicio (10%)</span>
                        <span className="text-slate-900">{formatPrice(total * 0.10)}</span>
                     </div>
                     <div className="border-t border-slate-100 pt-6 flex justify-between items-baseline">
                        <span className="text-slate-900 font-black text-lg">Total</span>
                        <span className="text-3xl font-black text-brand-600 tracking-tighter">{formatPrice(total * 1.10)}</span>
                     </div>
                  </div>

                  {step === 'cart' ? (
                     <button 
                        onClick={() => setStep('payment')}
                        disabled={items.length === 0}
                        className="w-full bg-slate-900 hover:bg-brand-600 disabled:opacity-30 disabled:cursor-not-allowed text-white py-4.5 rounded-2xl font-black shadow-xl transition-all flex items-center justify-center gap-3 group"
                     >
                        Confirmar Pedido <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                     </button>
                  ) : (
                     <button 
                        onClick={handlePayment}
                        disabled={isProcessing}
                        className="w-full bg-brand-600 hover:bg-brand-700 disabled:opacity-70 text-white py-4.5 rounded-2xl font-black shadow-xl shadow-brand-500/20 transition-all flex items-center justify-center gap-3"
                     >
                        {isProcessing ? (
                           <span className="w-5 h-5 border-4 border-white/30 border-t-white rounded-full animate-spin"></span>
                        ) : (
                           <>
                              <Lock className="w-5 h-5" /> Pagar {formatPrice(total * 1.10)}
                           </>
                        )}
                     </button>
                  )}

                  <div className="mt-8 flex items-center justify-center gap-3 text-[10px] font-black uppercase text-slate-400 tracking-widest">
                     <ShieldCheck className="w-4 h-4 text-green-500" /> Transacción Encriptada 256-bit
                  </div>
               </div>
            </div>

          </div>
        </div>
      </div>
    </>
  );
};
