import React, { useState, useMemo } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { RouteModel, CategoryType, GeoLocation } from '../types';
import { CATEGORY_METADATA } from '../constants';
import { RouteCard } from '../components/RouteCard';
import { SEOHelmet } from '../components/SEOHelmet';
import { Filter } from 'lucide-react';

interface CategoryDetailProps {
  allRoutes: RouteModel[];
  addToCart: (route: RouteModel) => void;
  location: GeoLocation;
}

export const CategoryDetail: React.FC<CategoryDetailProps> = ({ allRoutes, addToCart, location }) => {
  const { categoryId } = useParams<{ categoryId: string }>();
  const decodedCategory = decodeURIComponent(categoryId || '') as CategoryType;
  const navigate = useNavigate();

  const [filterDifficulty, setFilterDifficulty] = useState<string>('all');
  const [sortBy, setSortBy] = useState<string>('popular');

  const meta = CATEGORY_METADATA[decodedCategory];

  // Filter Logic
  const filteredRoutes = useMemo(() => {
    let result = allRoutes.filter(r => r.category === decodedCategory);
    
    // In a real app, we'd fetch based on the category, but here we mock filter existing
    // Since mock generator creates varied categories, we might not have many matches if we just filter the small subset.
    // For demo purposes, if 0 results, we show all to demonstrate UI.
    let actualMatches = result.length > 0 ? result : allRoutes.slice(0, 6); // Fallback for demo

    if (filterDifficulty !== 'all') {
      actualMatches = actualMatches.filter(r => r.difficulty === filterDifficulty);
    }

    if (sortBy === 'price_asc') actualMatches.sort((a, b) => a.price - b.price);
    if (sortBy === 'price_desc') actualMatches.sort((a, b) => b.price - a.price);
    if (sortBy === 'rating') actualMatches.sort((a, b) => b.rating - a.rating);

    return actualMatches;
  }, [allRoutes, decodedCategory, filterDifficulty, sortBy]);

  if (!meta) {
     return <div className="p-20 text-center">Categoría no encontrada. <button onClick={() => navigate('/categories')} className="text-brand-600 underline">Volver</button></div>;
  }

  return (
    <>
      <SEOHelmet 
        title={`Rutas de ${decodedCategory} en ${location.name}`} 
        description={`Las mejores rutas de ${decodedCategory.toLowerCase()} en ${location.name}. ${meta.desc}`}
        breadcrumbs={[
          { name: 'Categorías', item: '/categories' },
          { name: decodedCategory, item: `/category/${categoryId}` }
        ]} 
      />

      <div className="bg-slate-50 min-h-screen">
        {/* Header */}
        <div className="bg-white border-b border-slate-200">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
               <div>
                  <span className="text-brand-600 font-bold tracking-wide text-sm uppercase mb-2 block">{location.name}</span>
                  <h1 className="text-3xl md:text-5xl font-bold text-slate-900 flex items-center">
                    {decodedCategory}
                  </h1>
                  <p className="mt-4 text-slate-600 max-w-2xl text-lg">{meta.desc}</p>
               </div>
               
               {/* Stat Card */}
               <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100 min-w-[200px] text-center">
                  <span className="block text-4xl font-bold text-slate-900">{filteredRoutes.length}</span>
                  <span className="text-slate-500 text-sm font-medium uppercase">Rutas Disponibles</span>
               </div>
            </div>
          </div>
        </div>

        {/* Filters & Grid */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
           
           <div className="flex flex-col sm:flex-row justify-between items-center mb-8 gap-4 bg-white p-4 rounded-xl shadow-sm border border-slate-100">
              <div className="flex items-center gap-4 w-full sm:w-auto overflow-x-auto pb-2 sm:pb-0">
                 <div className="flex items-center text-slate-500 mr-2">
                    <Filter className="w-5 h-5 mr-2" />
                    <span className="font-semibold text-sm">Filtros:</span>
                 </div>
                 
                 <select 
                    value={filterDifficulty}
                    onChange={(e) => setFilterDifficulty(e.target.value)}
                    className="bg-slate-50 border border-slate-200 text-slate-700 text-sm rounded-lg focus:ring-brand-500 focus:border-brand-500 block p-2.5"
                 >
                    <option value="all">Todas las dificultades</option>
                    <option value="Fácil">Fácil</option>
                    <option value="Moderado">Moderado</option>
                    <option value="Difícil">Difícil</option>
                 </select>
              </div>

              <div className="flex items-center gap-2 w-full sm:w-auto">
                 <span className="text-sm text-slate-500">Ordenar por:</span>
                 <select 
                    value={sortBy}
                    onChange={(e) => setSortBy(e.target.value)}
                    className="bg-slate-50 border border-slate-200 text-slate-700 text-sm rounded-lg focus:ring-brand-500 focus:border-brand-500 block p-2.5 font-semibold"
                 >
                    <option value="popular">Popularidad</option>
                    <option value="rating">Mejor valoradas</option>
                    <option value="price_asc">Precio: Bajo a Alto</option>
                    <option value="price_desc">Precio: Alto a Bajo</option>
                 </select>
              </div>
           </div>

           {filteredRoutes.length === 0 ? (
             <div className="text-center py-20 bg-white rounded-2xl border border-dashed border-slate-300">
               <h3 className="text-xl font-bold text-slate-400">No hay rutas exactas con estos filtros</h3>
               <button onClick={() => setFilterDifficulty('all')} className="mt-4 text-brand-600 font-bold">Limpiar filtros</button>
             </div>
           ) : (
             <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {filteredRoutes.map(route => (
                   <RouteCard key={route.id} route={route} onAddToCart={addToCart} />
                ))}
             </div>
           )}

        </div>
      </div>
    </>
  );
};