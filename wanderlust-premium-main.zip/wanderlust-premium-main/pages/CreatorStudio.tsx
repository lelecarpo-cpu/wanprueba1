import React, { useState, useMemo, useEffect, useRef } from 'react';
import { MapComponent } from '../components/MapComponent';
import { RoutePoint, GeoLocation, CategoryType } from '../types';
import { Trash2, GripVertical, Eye, FileText, Map as MapIcon, Edit3, CornerDownRight, AlertCircle, ArrowLeft, Loader, UploadCloud, Settings, X, Info, Image as ImageIcon, Video, Mic, Type, Camera, RefreshCw, Plus } from 'lucide-react';
import { SEOHelmet } from '../components/SEOHelmet';
import { supabase } from '../supabaseClient';
import { useNavigate, useLocation as useRouterLocation } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';

// Declare google global
declare var google: any;

interface CreatorStudioProps {
  location: GeoLocation;
  onRouteUpdated?: () => void;
}

type MobileTab = 'list' | 'map' | 'edit';

// Helper to generate Supabase-compatible UUIDs
const generateUUID = () => {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
    const r = Math.random() * 16 | 0;
    const v = c === 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
};

const isValidUUID = (uuid: string) => {
  if (!uuid) return false;
  const regex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
  return regex.test(uuid);
};

// --- FIX START: Robust Sanitize POV Helper ---
const sanitizePov = (config: any) => {
  // Hardcoded safe defaults
  const SAFE_HEADING = 0;
  const SAFE_PITCH = 0;
  const SAFE_ZOOM = 1;

  if (!config || typeof config !== 'object') {
    return { heading: SAFE_HEADING, pitch: SAFE_PITCH, zoom: SAFE_ZOOM };
  }

  // Helper to ensure number is finite
  const getFiniteNumber = (val: any, fallback: number): number => {
    if (val === null || val === undefined) return fallback;
    const num = Number(val);
    // Strict finite check (filters out NaN, Infinity)
    return Number.isFinite(num) ? num : fallback;
  };

  const heading = getFiniteNumber(config.heading, SAFE_HEADING);
  const pitch = getFiniteNumber(config.pitch, SAFE_PITCH);
  
  // Zoom specific logic: fallback to 1, clamp between 0 and 3
  let zoom = getFiniteNumber(config.zoom, SAFE_ZOOM);
  zoom = Math.max(0, Math.min(3, zoom));

  return { heading, pitch, zoom };
};
// --- FIX END ---

export const CreatorStudio: React.FC<CreatorStudioProps> = ({ location, onRouteUpdated }) => {
  const [points, setPoints] = useState<RoutePoint[]>([]);
  const [selectedPointId, setSelectedPointId] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<'map' | 'street'>('map');
  const [mobileTab, setMobileTab] = useState<MobileTab>('map');
  const [isSaving, setIsSaving] = useState(false);
  const [saveStatus, setSaveStatus] = useState<'idle' | 'drafting' | 'publishing'>('idle');
  const navigate = useNavigate();
  const { user } = useAuth();
  const routerLocation = useRouterLocation();

  const [routeId, setRouteId] = useState<string | null>(null);
  const [routeTitle, setRouteTitle] = useState("Nueva Ruta");
  const [routeCategory, setRouteCategory] = useState<CategoryType>(CategoryType.TURISMO);
  const [routeDescription, setRouteDescription] = useState("");
  const [currentStatus, setCurrentStatus] = useState<'draft' | 'published'>('draft');
  const [showSettings, setShowSettings] = useState(false);

  // New Hotspot States
  const [showHotspotModal, setShowHotspotModal] = useState(false);
  const [tempHotspotLoc, setTempHotspotLoc] = useState<{lat: number, lng: number, x?: number, y?: number} | null>(null);
  const [newHotspotType, setNewHotspotType] = useState<'text' | 'audio' | 'video' | 'image'>('text');
  const [newHotspotContent, setNewHotspotContent] = useState('');
  const [newHotspotTitle, setNewHotspotTitle] = useState('');

  // Mode inside Street View: 'live' (moving camera) or 'snapshot' (editing static image)
  const [streetMode, setStreetMode] = useState<'live' | 'snapshot'>('live');

  // References
  const streetViewRef = useRef<any>(null);
  const pointsRef = useRef<RoutePoint[]>(points); // Ref to hold latest points for event listeners
  const imageRef = useRef<HTMLImageElement>(null);

  // Update points ref whenever points change
  useEffect(() => {
    pointsRef.current = points;
  }, [points]);

  useEffect(() => {
    if (routerLocation.state && (routerLocation.state as any).editRoute) {
        const editRoute = (routerLocation.state as any).editRoute;
        setRouteTitle(editRoute.title);
        if (editRoute.status) setCurrentStatus(editRoute.status);
        if (editRoute.category) setRouteCategory(editRoute.category);
        if (editRoute.description) setRouteDescription(editRoute.description);
        
        if (editRoute.id && isValidUUID(editRoute.id)) {
            setRouteId(editRoute.id);
            fetchRoutePoints(editRoute.id);
        } else {
            setRouteId(null);
        }
    }
  }, [routerLocation.state]);

  const fetchRoutePoints = async (id: string) => {
    const { data, error } = await supabase.from('route_points').select('*').eq('route_id', id);
    if (data) {
        const mappedPoints: RoutePoint[] = data.map((p: any) => ({
            id: p.id,
            parentId: p.parent_id,
            lat: p.lat,
            lng: p.lng,
            title: p.title,
            description: p.description,
            mediaType: p.media_type,
            durationMin: p.duration_min,
            streetViewConfig: p.street_view_config,
            streetViewTarget: p.street_view_target,
            mediaUrl: p.media_url,
            snapshotUrl: p.snapshot_url
        }));
        setPoints(mappedPoints);
    }
  };

  const selectedPoint = points.find(p => p.id === selectedPointId);

  const activeParentId = useMemo(() => {
    if (!selectedPoint) return null;
    return selectedPoint.parentId || selectedPoint.id;
  }, [selectedPoint]);

  const activeParentPoint = points.find(p => p.id === activeParentId);
  const hasSnapshot = !!activeParentPoint?.snapshotUrl;

  // Sync streetMode with selected point snapshot status
  useEffect(() => {
    if (hasSnapshot) {
        setStreetMode('snapshot');
    } else {
        setStreetMode('live');
    }
  }, [activeParentId, hasSnapshot]);

  const currentViewSubPoints = useMemo(() => 
    points.filter(p => p.parentId === activeParentId),
  [points, activeParentId]);

  // Points that have snapshots (Scenes)
  const scenes = useMemo(() => points.filter(p => !p.parentId && p.snapshotUrl), [points]);

  // Street View Initialization
  useEffect(() => {
    let initTimer: any = null;
    let povListener: any = null;
    let zoomListener: any = null;
    let debounceTimer: any = null;

    if (viewMode === 'street' && streetMode === 'live' && typeof google !== 'undefined' && activeParentPoint) {
        // Wait for DOM
        initTimer = setTimeout(() => {
            const container = document.getElementById("street-view");
            if (container) {
                const center = { lat: activeParentPoint.lat, lng: activeParentPoint.lng };
                
                const rawConfig = activeParentPoint.streetViewConfig || {};
                const safeConfig = sanitizePov(rawConfig);
                
                // Protección extra explícita antes de crear el objeto
                const finalZoom = Number.isFinite(safeConfig.zoom) ? safeConfig.zoom : 1;
                const finalHeading = Number.isFinite(safeConfig.heading) ? safeConfig.heading : 0;
                const finalPitch = Number.isFinite(safeConfig.pitch) ? safeConfig.pitch : 0;

                // Initialize Panorama with STRICT separation
                const panorama = new google.maps.StreetViewPanorama(container, {
                    position: center,
                    // POV object MUST ONLY contain heading and pitch
                    pov: { 
                        heading: finalHeading, 
                        pitch: finalPitch 
                    },
                    // Zoom MUST be a root property of StreetViewPanoramaOptions
                    zoom: finalZoom,
                    linksControl: true,
                    panControl: true,
                    enableCloseButton: false,
                    clickToGo: true,
                    addressControl: false,
                    fullscreenControl: false,
                    motionTracking: false,
                    motionTrackingControl: false,
                    showRoadLabels: false
                });

                streetViewRef.current = panorama;

                const handleViewUpdate = () => {
                    if (!streetViewRef.current) return;
                    
                    // 1. Get POV (Returns { heading, pitch })
                    const currentPov = streetViewRef.current.getPov();
                    // 2. Get Zoom explicitly via getZoom()
                    const currentZoom = streetViewRef.current.getZoom();

                    // Guard: verify we have data
                    if (!currentPov || typeof currentZoom !== 'number') return;

                    // 3. Sanitize both just in case
                    const safeState = sanitizePov({ 
                        heading: currentPov.heading, 
                        pitch: currentPov.pitch, 
                        zoom: currentZoom 
                    });

                    clearTimeout(debounceTimer);
                    debounceTimer = setTimeout(() => {
                        setPoints(prevPoints => prevPoints.map(p => 
                            p.id === activeParentId 
                            ? { 
                                ...p, 
                                // Save consolidated config for DB/State
                                streetViewConfig: { 
                                    heading: safeState.heading, 
                                    pitch: safeState.pitch,
                                    zoom: safeState.zoom
                                } 
                              } 
                            : p
                        ));
                    }, 500);
                };

                // Add listeners for BOTH pov and zoom changes
                povListener = panorama.addListener('pov_changed', handleViewUpdate);
                zoomListener = panorama.addListener('zoom_changed', handleViewUpdate);
            }
        }, 100);
    }

    // Cleanup function
    return () => {
        if (initTimer) clearTimeout(initTimer);
        if (debounceTimer) clearTimeout(debounceTimer);
        if (povListener && typeof google !== 'undefined') google.maps.event.removeListener(povListener);
        if (zoomListener && typeof google !== 'undefined') google.maps.event.removeListener(zoomListener);
    };
  }, [viewMode, streetMode, activeParentId]); 

  // Handle Capture Snapshot
  const handleCaptureSnapshot = () => {
      if (!streetViewRef.current || !activeParentPoint) return;

      // Get separated values
      const rawPov = streetViewRef.current.getPov();
      const rawZoom = streetViewRef.current.getZoom();
      
      const pov = sanitizePov({ ...rawPov, zoom: rawZoom });
      
      const pos = streetViewRef.current.getPosition();
      
      // Hardcoded key from index.html
      const apiKey = 'AIzaSyDHN4ut1zwr2MP5KpYC5jH_mkKUIX-_Zxk';

      if (!apiKey) {
          alert("Error: API Key no configurada.");
          return;
      }

      // Safe check for coordinates
      const lat = typeof pos.lat === 'function' ? pos.lat() : pos.lat;
      const lng = typeof pos.lng === 'function' ? pos.lng() : pos.lng;

      // Construct Static Image URL
      const snapshotUrl = `https://maps.googleapis.com/maps/api/streetview?size=600x400&location=${lat},${lng}&heading=${pov.heading}&pitch=${pov.pitch}&fov=90&key=${apiKey}`;

      // Update Parent Point with Snapshot URL AND the current view config
      setPoints(prev => prev.map(p => 
          p.id === activeParentPoint.id 
          ? { 
              ...p, 
              snapshotUrl: snapshotUrl, 
              streetViewConfig: { 
                  heading: pov.heading, 
                  pitch: pov.pitch,
                  zoom: pov.zoom 
              } 
            } 
          : p
      ));
      
      setStreetMode('snapshot');
  };

  const handleRetakeSnapshot = () => {
      if (!activeParentPoint) return;
      if (confirm("¿Volver a la cámara en vivo? Podrás tomar una nueva captura.")) {
           setStreetMode('live');
      }
  };

  const handleImageClick = (e: React.MouseEvent<HTMLImageElement>) => {
      if (!imageRef.current) return;
      
      const rect = imageRef.current.getBoundingClientRect();
      const x = ((e.clientX - rect.left) / rect.width) * 100;
      const y = ((e.clientY - rect.top) / rect.height) * 100;

      // Access latest points via ref to avoid stale closures
      const currentSubPoints = pointsRef.current.filter(p => p.parentId === activeParentId);

      setTempHotspotLoc({ lat: 0, lng: 0, x, y });
      setNewHotspotTitle(`Info ${currentSubPoints.length + 1}`);
      setNewHotspotContent('');
      setNewHotspotType('text');
      setShowHotspotModal(true);
  };

  const confirmHotspotCreation = () => {
    if (!tempHotspotLoc || !activeParentId) return;

    const newPointId = generateUUID();
    const newPoint: RoutePoint = {
        id: newPointId,
        parentId: activeParentId,
        lat: activeParentPoint?.lat || 0, // Fallback lat/lng
        lng: activeParentPoint?.lng || 0,
        title: newHotspotTitle,
        description: newHotspotType === 'text' ? newHotspotContent : '',
        mediaType: newHotspotType,
        mediaUrl: newHotspotType !== 'text' ? newHotspotContent : undefined,
        durationMin: 0,
        streetViewTarget: { x: tempHotspotLoc.x || 0, y: tempHotspotLoc.y || 0 }
    };

    setPoints(prev => [...prev, newPoint]);
    setSelectedPointId(newPointId);
    setShowHotspotModal(false);
    setTempHotspotLoc(null);
    
    if (window.innerWidth < 768) {
       setMobileTab('edit');
    }
  };

  const handleAddPoint = (lat: number, lng: number) => {
    const newPoint: RoutePoint = {
      id: generateUUID(),
      lat,
      lng,
      title: `Parada ${points.filter(p => !p.parentId).length + 1}`,
      description: '',
      mediaType: 'none',
      durationMin: 10,
      streetViewConfig: { heading: 0, pitch: 0, zoom: 1 } // Default POV
    };
    setPoints([...points, newPoint]);
    setSelectedPointId(newPoint.id);
    
    if (window.innerWidth < 768) {
      setMobileTab('edit');
    }
  };

  const updatePoint = (id: string, updates: Partial<RoutePoint>) => {
    setPoints(points.map(p => p.id === id ? { ...p, ...updates } : p));
  };

  const removePoint = (id: string) => {
    setPoints(points.filter(p => p.id !== id && p.parentId !== id));
    if (selectedPointId === id) setSelectedPointId(null);
  };

  const handleSaveRoute = async (status: 'draft' | 'published') => {
    if (!user) {
        if(confirm("Debes iniciar sesión para guardar. ¿Ir al login?")) {
            navigate('/auth');
        }
        return;
    }

    if (points.length === 0) {
        alert("Añade al menos un punto al mapa.");
        return;
    }

    setIsSaving(true);
    setSaveStatus(status === 'draft' ? 'drafting' : 'publishing');
    
    try {
        const routePayload = {
            title: routeTitle,
            slug: routeTitle.toLowerCase().replace(/\s+/g, '-') + '-' + Math.floor(Math.random() * 1000),
            description: routeDescription || "Ruta creada con Creator Studio",
            category: routeCategory,
            price: 9.99,
            rating: 0,
            reviews: 0,
            difficulty: "Moderado",
            distance_km: 5.0,
            duration_min: points.reduce((acc, p) => acc + (p.durationMin || 0), 0),
            thumbnail: activeParentPoint?.snapshotUrl || `https://picsum.photos/seed/${Date.now()}/800/600`, // Use snapshot as thumbnail if available
            location: location,
            creator_id: user.id,
            tags: ['Nuevo', 'User Generated'],
            status: status
        };

        let currentRouteId = routeId;

        if (currentRouteId && isValidUUID(currentRouteId)) {
             const { error } = await supabase.from('routes').update(routePayload).eq('id', currentRouteId);
             if (error) throw error;
        } else {
             const { data, error } = await supabase.from('routes').insert(routePayload).select().single();
             if (error) throw error;
             if (data) {
                 currentRouteId = data.id;
                 setRouteId(data.id);
             }
        }

        if (currentRouteId) {
             const { error: deleteError } = await supabase.from('route_points').delete().eq('route_id', currentRouteId);
             if (deleteError) throw deleteError;
             
             const pointsPayload = points.map(p => ({
                id: isValidUUID(p.id) ? p.id : generateUUID(),
                route_id: currentRouteId,
                parent_id: (p.parentId && isValidUUID(p.parentId)) ? p.parentId : null,
                lat: p.lat,
                lng: p.lng,
                title: p.title,
                description: p.description,
                media_type: p.mediaType,
                duration_min: p.durationMin,
                street_view_config: p.streetViewConfig,
                street_view_target: p.streetViewTarget,
                media_url: p.mediaUrl,
                snapshot_url: p.snapshotUrl
             }));

             if (pointsPayload.length > 0) {
                const { error: pointsError } = await supabase.from('route_points').insert(pointsPayload);
                if (pointsError) throw pointsError;
             }
        }

        if (onRouteUpdated) onRouteUpdated();

        setCurrentStatus(status);
        alert(status === 'published' ? "¡Ruta publicada!" : "Borrador guardado.");
        if (status === 'published') navigate('/profile');
        
    } catch (err: any) {
        console.error("Error saving route:", err);
        alert("Error al guardar la ruta. Inténtalo de nuevo.");
    } finally {
        setIsSaving(false);
        setSaveStatus('idle');
    }
  };

  const PointRow: React.FC<{ point: RoutePoint, isChild?: boolean }> = ({ point, isChild = false }) => {
      const isSelected = selectedPointId === point.id;
      const isParentOfSelected = !isChild && selectedPoint?.parentId === point.id;
      
      const Icon = point.mediaType === 'audio' ? Mic : point.mediaType === 'video' ? Video : point.mediaType === 'image' ? ImageIcon : FileText;

      return (
        <div 
          onClick={() => setSelectedPointId(point.id)}
          className={`
            relative p-3 rounded-lg border cursor-pointer transition-all hover:shadow-md flex items-start space-x-3 mb-2
            ${isChild ? 'ml-8 mt-1 border-l-4 border-l-slate-300' : ''}
            ${isSelected 
                ? 'border-brand-500 bg-brand-50 ring-1 ring-brand-500 z-10' 
                : isParentOfSelected 
                    ? 'border-brand-200 bg-brand-50/30' 
                    : 'border-slate-200 bg-white'
            }
          `}
        >
          {isChild && <div className="absolute -left-6 top-0 w-4 h-6 border-b-2 border-l-2 border-slate-300 rounded-bl-lg pointer-events-none opacity-50"></div>}
          <div className="mt-1 text-slate-400 cursor-move"><GripVertical className="w-4 h-4" /></div>
          <div className="flex-grow min-w-0">
            <div className="flex justify-between items-start">
              <span className={`text-[10px] font-bold mb-1 uppercase tracking-wide flex items-center gap-1 ${isChild ? 'text-purple-600' : 'text-brand-600'}`}>
                {isChild ? (
                    <>
                        <Icon className="w-3 h-3" /> {point.mediaType}
                    </>
                ) : 'Parada'}
              </span>
              <button onClick={(e) => { e.stopPropagation(); removePoint(point.id); }} className="text-slate-300 hover:text-red-500 p-1">
                <Trash2 className="w-3 h-3" />
              </button>
            </div>
            <div className="flex items-center gap-1.5">
                {isChild && <CornerDownRight className="w-3 h-3 text-slate-400" />}
                <h4 className={`text-sm font-semibold truncate ${isSelected ? 'text-slate-900' : 'text-slate-700'}`}>
                    {point.title}
                </h4>
            </div>
          </div>
        </div>
      );
  };

  if (!user) {
    return (
        <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
             <div className="bg-white p-8 rounded-2xl shadow-xl text-center max-w-md w-full border border-slate-100">
                 <div className="w-16 h-16 bg-brand-100 text-brand-600 rounded-full flex items-center justify-center mx-auto mb-6">
                    <AlertCircle className="w-8 h-8" />
                 </div>
                 <h2 className="text-2xl font-bold text-slate-900 mb-2">Acceso Restringido</h2>
                 <p className="text-slate-500 mb-6">Debes iniciar sesión para acceder al estudio.</p>
                 <button onClick={() => navigate('/auth')} className="w-full bg-slate-900 text-white py-3 rounded-xl font-bold hover:bg-brand-600 transition-colors">
                     Iniciar Sesión
                 </button>
             </div>
        </div>
    )
  }

  return (
    <>
      <SEOHelmet title="Creator Studio" description="Crea y diseña rutas digitales." />
      
      <div className="flex flex-col h-[calc(100vh-64px)] md:h-[calc(100vh-64px)] overflow-hidden bg-slate-50">
        <div className="bg-white border-b border-slate-200 p-3 md:p-4 flex justify-between items-center shadow-sm z-30 shrink-0">
          <div className="flex items-center gap-3">
             <button onClick={() => navigate(-1)} className="md:hidden text-slate-400 hover:text-slate-600"><ArrowLeft className="w-6 h-6" /></button>
             <div className="bg-brand-100 p-2 rounded-lg text-brand-600 hidden md:block"><MapIcon className="w-5 h-5" /></div>
             <div>
                <input 
                    type="text" 
                    value={routeTitle} 
                    onChange={(e) => setRouteTitle(e.target.value)}
                    className="text-lg md:text-xl font-bold text-slate-800 bg-transparent border-none focus:ring-0 p-0 placeholder-slate-300 w-40 md:w-64"
                    placeholder="Nombre de la Ruta"
                />
                <div className="flex items-center gap-2">
                    <p className="text-[10px] md:text-xs text-slate-500">
                    {points.length} puntos • {routeId ? (currentStatus === 'published' ? 'Publicado' : 'Borrador') : 'Nueva Ruta'}
                    </p>
                    {isSaving && <span className="text-[10px] text-brand-600 animate-pulse font-bold">Guardando...</span>}
                    
                    <button 
                        onClick={() => setShowSettings(true)}
                        className="flex items-center gap-1 ml-2 px-2 py-0.5 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-500 hover:text-brand-600 transition-colors"
                        title="Configuración de ruta"
                    >
                        <Settings className="w-3 h-3" />
                        <span className="text-[10px] font-bold">Ajustes</span>
                    </button>
                </div>
             </div>
          </div>
          <div className="flex space-x-2 md:space-x-3">
             <div className="hidden md:flex bg-slate-100 p-1 rounded-lg">
                <button onClick={() => setViewMode('map')} className={`px-3 py-1 text-sm font-medium rounded-md transition-all ${viewMode === 'map' ? 'bg-white shadow text-slate-900' : 'text-slate-500 hover:text-slate-900'}`}>Mapa</button>
                <button onClick={() => setViewMode('street')} disabled={!activeParentId} className={`px-3 py-1 text-sm font-medium rounded-md transition-all flex items-center ${viewMode === 'street' ? 'bg-white shadow text-slate-900' : 'text-slate-500 hover:text-slate-900 disabled:opacity-50'}`}><Eye className="w-3 h-3 mr-1" /> Editor Vista</button>
             </div>
             
             <button onClick={() => handleSaveRoute('draft')} disabled={isSaving} className="flex items-center space-x-2 bg-white border border-slate-200 hover:bg-slate-50 text-slate-600 px-3 py-1.5 md:px-4 md:py-2 rounded-lg text-xs md:text-sm font-bold shadow-sm transition-all">
                {saveStatus === 'drafting' ? <Loader className="w-3 h-3 animate-spin" /> : <FileText className="w-3 h-3 md:w-4 md:h-4" />}
                <span className="hidden sm:inline">Borrador</span>
             </button>

             <button onClick={() => handleSaveRoute('published')} disabled={isSaving} className="flex items-center space-x-2 bg-brand-600 hover:bg-brand-700 text-white px-3 py-1.5 md:px-4 md:py-2 rounded-lg text-xs md:text-sm font-bold shadow-md transition-all">
                {saveStatus === 'publishing' ? <Loader className="w-3 h-3 animate-spin" /> : <UploadCloud className="w-3 h-3 md:w-4 md:h-4" />}
                <span>Publicar</span>
             </button>
          </div>
        </div>

        <div className="md:hidden flex bg-white border-b border-slate-200 px-4">
           <button onClick={() => setMobileTab('list')} className={`flex-1 py-3 text-sm font-medium border-b-2 ${mobileTab === 'list' ? 'border-brand-600 text-brand-600' : 'border-transparent text-slate-500'}`}>Lista</button>
           <button onClick={() => setMobileTab('map')} className={`flex-1 py-3 text-sm font-medium border-b-2 ${mobileTab === 'map' ? 'border-brand-600 text-brand-600' : 'border-transparent text-slate-500'}`}>Visual</button>
           <button onClick={() => setMobileTab('edit')} disabled={!selectedPointId} className={`flex-1 py-3 text-sm font-medium border-b-2 ${mobileTab === 'edit' ? 'border-brand-600 text-brand-600' : 'border-transparent text-slate-400'}`}>Editar</button>
        </div>

        <div className="flex flex-grow h-full overflow-hidden relative">
          
          <div className={`w-full md:w-80 bg-white border-r border-slate-200 flex flex-col overflow-hidden z-20 absolute md:relative inset-0 transition-transform duration-300 ${mobileTab === 'list' ? 'translate-x-0' : '-translate-x-full md:translate-x-0'}`}>
            <div className="p-4 bg-slate-50 border-b border-slate-200">
               <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider">Estructura de la Ruta</h3>
            </div>
            
            <div className="flex-grow overflow-y-auto p-2">
              {points.length === 0 && (
                <div className="text-center py-10 text-slate-400 px-4">
                    <div className="border-2 border-dashed border-slate-200 rounded-lg p-6">
                        <MapIcon className="w-8 h-8 mx-auto mb-2 text-slate-300" />
                        <p className="text-sm">Ve al mapa para añadir tu primer punto.</p>
                    </div>
                </div>
              )}
              {points.filter(p => !p.parentId).map((parent) => (
                <React.Fragment key={parent.id}>
                    <PointRow point={parent} />
                    {points.filter(child => child.parentId === parent.id).map(child => (
                        <PointRow key={child.id} point={child} isChild={true} />
                    ))}
                </React.Fragment>
              ))}
            </div>
          </div>

          <div className={`flex-grow relative bg-slate-100 absolute md:relative inset-0 transition-transform duration-300 flex flex-col ${mobileTab === 'map' ? 'translate-x-0' : 'translate-x-full md:translate-x-0'}`}>
            {viewMode === 'map' ? (
              <MapComponent 
                center={location}
                points={points}
                editable={true}
                onAddPoint={handleAddPoint}
                onSelectPoint={(id) => { setSelectedPointId(id); if (window.innerWidth < 768) setMobileTab('edit'); }}
                selectedPointId={selectedPointId || undefined}
              />
            ) : (
              <div 
                className={`w-full h-full relative overflow-hidden select-none bg-slate-900 flex flex-col ${activeParentId ? 'cursor-default' : 'cursor-not-allowed'}`}
              >
                {!activeParentId ? (
                    <div className="w-full h-full flex flex-col items-center justify-center text-white p-6 text-center">
                        <MapIcon className="w-12 h-12 mb-4 text-slate-600" />
                        <h3 className="text-xl font-bold mb-2">Selecciona un Punto del Mapa</h3>
                        <p className="text-slate-400 max-w-md">Debes seleccionar un punto principal para editar su vista inmersiva.</p>
                        <button onClick={() => setViewMode('map')} className="mt-6 bg-brand-600 hover:bg-brand-500 px-6 py-2 rounded-full font-bold transition-colors">Volver al Mapa</button>
                    </div>
                ) : (
                    <>
                        {/* MAIN EDITOR AREA */}
                        <div className="flex-grow relative">
                            {streetMode === 'snapshot' && hasSnapshot ? (
                                // SNAPSHOT EDITOR MODE
                                <div className="relative w-full h-full flex items-center justify-center bg-black p-4 overflow-hidden">
                                    <div className="relative max-w-full max-h-full shadow-2xl">
                                        <img 
                                            ref={imageRef}
                                            src={activeParentPoint.snapshotUrl} 
                                            alt="Vista capturada" 
                                            className="block max-w-full max-h-full object-contain cursor-crosshair"
                                            style={{ maxHeight: '100%' }}
                                            onClick={handleImageClick}
                                        />
                                        {/* Render 2D Markers inside this wrapper so they stick to the image content */}
                                        {currentViewSubPoints.map(sp => {
                                            if(sp.streetViewTarget?.x !== undefined) {
                                                return (
                                                    <div 
                                                        key={sp.id}
                                                        style={{ left: `${sp.streetViewTarget?.x}%`, top: `${sp.streetViewTarget?.y}%` }}
                                                        className="absolute transform -translate-x-1/2 -translate-y-1/2 cursor-pointer z-10"
                                                        onClick={(e) => { e.stopPropagation(); setSelectedPointId(sp.id); }}
                                                    >
                                                        <div className={`w-6 h-6 rounded-full border-2 border-white shadow-md flex items-center justify-center ${selectedPointId === sp.id ? 'bg-brand-500 scale-125' : 'bg-slate-900'}`}>
                                                            <div className="w-2 h-2 bg-white rounded-full animate-pulse"></div>
                                                        </div>
                                                        <span className="absolute top-full left-1/2 -translate-x-1/2 mt-1 bg-black/70 text-white text-[10px] px-2 py-0.5 rounded-full whitespace-nowrap backdrop-blur-sm pointer-events-none">
                                                            {sp.title}
                                                        </span>
                                                    </div>
                                                )
                                            }
                                            return null;
                                        })}
                                        
                                        {/* Helper Badge Overlay */}
                                        <div className="absolute top-4 left-0 right-0 pointer-events-none flex justify-center w-full px-4">
                                            <div className="bg-black/60 text-white px-4 py-2 rounded-full backdrop-blur-md text-sm border border-white/10 shadow-lg flex items-center gap-2">
                                                <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
                                                Modo Edición: Haz clic en la imagen para añadir info
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            ) : (
                                // LIVE STREET VIEW MODE
                                <div className="relative w-full h-full">
                                    <div id="street-view" style={{ width: '100%', height: '100%' }}></div>
                                    <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10 pointer-events-auto">
                                        <button 
                                            onClick={handleCaptureSnapshot}
                                            className="bg-brand-600 hover:bg-brand-500 text-white px-8 py-4 rounded-full font-bold text-lg shadow-xl hover:scale-105 active:scale-95 transition-all flex items-center gap-2 border-4 border-brand-800/50"
                                        >
                                            <Camera className="w-6 h-6" /> Capturar Vista
                                        </button>
                                        <p className="text-white/80 text-xs text-center mt-3 bg-black/40 px-3 py-1 rounded-full backdrop-blur-sm pointer-events-none">
                                            Encuadra y captura para crear la escena
                                        </p>
                                    </div>
                                </div>
                            )}
                        </div>

                        {/* BOTTOM FILMSTRIP GALLERY */}
                        <div className="h-28 bg-slate-950 border-t border-slate-800 flex items-center px-4 gap-3 overflow-x-auto shrink-0 z-20">
                            {/* Live Camera Button */}
                            <button 
                                onClick={() => setStreetMode('live')}
                                className={`shrink-0 w-20 h-20 rounded-lg border-2 flex flex-col items-center justify-center gap-1 transition-all ${streetMode === 'live' ? 'border-brand-500 bg-slate-800' : 'border-slate-700 hover:bg-slate-800 hover:border-slate-500'}`}
                            >
                                <RefreshCw className={`w-6 h-6 ${streetMode === 'live' ? 'text-brand-500' : 'text-slate-400'}`} />
                                <span className="text-[9px] font-bold text-slate-400 uppercase">Cámara</span>
                            </button>
                            
                            <div className="w-px h-12 bg-slate-800 mx-1"></div>

                            {/* Scenes List */}
                            {scenes.length === 0 ? (
                                <span className="text-slate-600 text-xs italic ml-2">Las capturas aparecerán aquí...</span>
                            ) : (
                                scenes.map((scene) => (
                                    <button 
                                        key={scene.id}
                                        onClick={() => { setSelectedPointId(scene.id); setStreetMode('snapshot'); }}
                                        className={`shrink-0 w-32 h-20 rounded-lg border-2 relative overflow-hidden group transition-all ${activeParentId === scene.id && streetMode === 'snapshot' ? 'border-brand-500 ring-2 ring-brand-500/20' : 'border-slate-700 hover:border-slate-500'}`}
                                    >
                                        <img src={scene.snapshotUrl} alt={scene.title} className="w-full h-full object-cover" />
                                        <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent flex flex-col justify-end p-1.5">
                                            <span className="text-[10px] text-white font-bold truncate block">{scene.title}</span>
                                        </div>
                                        {activeParentId === scene.id && streetMode === 'snapshot' && (
                                            <div className="absolute top-1 right-1 w-2 h-2 bg-brand-500 rounded-full shadow-sm"></div>
                                        )}
                                    </button>
                                ))
                            )}
                        </div>
                    </>
                )}
                <button onClick={(e) => { e.stopPropagation(); setViewMode('map'); }} className="absolute top-4 left-4 bg-white/90 p-2 rounded-full shadow-lg text-slate-800 md:hidden z-40"><ArrowLeft className="w-5 h-5" /></button>
              </div>
            )}
            
            {viewMode === 'map' && activeParentId && (
                <button onClick={() => setViewMode('street')} className="absolute bottom-6 right-6 bg-white text-slate-900 p-3 rounded-full shadow-xl z-[400] md:hidden border border-slate-200"><Eye className="w-6 h-6 text-brand-600" /></button>
            )}
          </div>

          <div className={`w-full md:w-80 bg-white border-l border-slate-200 flex flex-col overflow-y-auto z-20 absolute md:relative inset-0 transition-transform duration-300 shadow-xl ${mobileTab === 'edit' ? 'translate-x-0' : 'translate-x-full md:translate-x-0'}`}>
            {selectedPoint ? (
              <div className="p-5 pb-20 md:pb-5">
                <div className="flex justify-between items-center mb-4 md:hidden">
                    <h3 className="font-bold text-lg text-slate-900">Editar Punto</h3>
                    <button onClick={() => setMobileTab('map')} className="text-slate-500 text-sm">Cerrar</button>
                </div>
                
                <div className="mb-6">
                    <div className="flex items-center gap-2 mb-1">
                        {selectedPoint.parentId ? <span className="bg-purple-100 text-purple-700 text-[10px] font-bold px-2 py-1 rounded-full uppercase">Punto Info</span> : <span className="bg-brand-100 text-brand-700 text-[10px] font-bold px-2 py-1 rounded-full uppercase">Parada</span>}
                        <span className="text-xs text-slate-400 font-mono">#{selectedPoint.id.substr(0,4)}</span>
                    </div>
                    <input type="text" value={selectedPoint.title} onChange={(e) => updatePoint(selectedPoint.id, { title: e.target.value })} className="font-bold text-xl text-slate-900 leading-tight w-full border-none focus:ring-0 p-0" />
                </div>
                
                <div className="space-y-5">
                  <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1.5">Descripción</label>
                    <textarea rows={4} value={selectedPoint.description} onChange={(e) => updatePoint(selectedPoint.id, { description: e.target.value })} className="w-full border border-slate-300 rounded-lg px-3 py-2.5 text-sm focus:ring-2 focus:ring-brand-500 focus:border-transparent outline-none transition-all resize-none" />
                  </div>
                  
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                        <label className="block text-xs font-bold text-slate-500 uppercase mb-1.5">Duración (min)</label>
                        <input type="number" min="0" value={selectedPoint.durationMin} onChange={(e) => updatePoint(selectedPoint.id, { durationMin: parseInt(e.target.value) || 0 })} className="w-full border border-slate-300 rounded-lg px-3 py-2.5 text-sm" />
                    </div>
                     <div>
                        <label className="block text-xs font-bold text-slate-500 uppercase mb-1.5">Tipo Media</label>
                        <select value={selectedPoint.mediaType} onChange={(e) => updatePoint(selectedPoint.id, { mediaType: e.target.value as any })} className="w-full border border-slate-300 rounded-lg px-3 py-2.5 text-sm focus:ring-2 focus:ring-brand-500 focus:border-transparent outline-none transition-all bg-white">
                            <option value="none">Ninguno</option>
                            <option value="text">Texto</option>
                            <option value="image">Imagen</option>
                            <option value="video">Video</option>
                            <option value="audio">Audio</option>
                        </select>
                    </div>
                  </div>

                  {selectedPoint.mediaType !== 'none' && selectedPoint.mediaType !== 'text' && (
                      <div className="mt-4 p-3 bg-slate-50 rounded-lg border border-slate-200">
                          <label className="block text-xs font-bold text-slate-500 uppercase mb-1.5">URL del Contenido</label>
                          <input type="text" placeholder="https://..." value={selectedPoint.mediaUrl || ''} onChange={(e) => updatePoint(selectedPoint.id, { mediaUrl: e.target.value })} className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-brand-500" />
                      </div>
                  )}

                  {selectedPoint.parentId && (
                    <div className="p-3 bg-blue-50 rounded-lg border border-blue-100 flex gap-2">
                        <Info className="w-4 h-4 text-blue-500 shrink-0 mt-0.5" />
                        <p className="text-xs text-blue-700">Este punto aparecerá sobre la imagen capturada de la parada principal.</p>
                    </div>
                  )}

                  <div className="mt-8 pt-6 border-t border-slate-100">
                      <button onClick={() => removePoint(selectedPoint.id)} className="w-full flex items-center justify-center gap-2 text-red-500 hover:text-red-600 hover:bg-red-50 py-3 rounded-lg transition-colors font-medium text-sm">
                          <Trash2 className="w-4 h-4" /> Eliminar Punto
                      </button>
                  </div>
                </div>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center h-full text-slate-400 p-8 text-center">
                 <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mb-4"><Edit3 className="w-8 h-8 text-slate-300" /></div>
                 <p className="font-medium text-slate-600 mb-1">Nada seleccionado</p>
                 <p className="text-sm">Haz clic en un punto del mapa o de la lista para editar.</p>
              </div>
            )}
          </div>
        </div>

        {/* Hotspot Creation Modal */}
        {showHotspotModal && (
            <div className="fixed inset-0 z-[150] bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in">
                <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden animate-fade-in-up">
                    <div className="p-6 border-b border-slate-100 flex justify-between items-center">
                        <h3 className="text-xl font-bold text-slate-900">Nuevo Contenido</h3>
                        <button onClick={() => setShowHotspotModal(false)} className="text-slate-400 hover:text-slate-600"><X className="w-5 h-5" /></button>
                    </div>
                    <div className="p-6">
                        <div className="mb-4">
                            <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Título</label>
                            <input 
                                type="text" 
                                value={newHotspotTitle} 
                                onChange={(e) => setNewHotspotTitle(e.target.value)} 
                                className="w-full border border-slate-300 rounded-xl px-4 py-3 text-slate-900 focus:ring-2 focus:ring-brand-500 outline-none"
                                placeholder="Ej. Detalle de la fachada"
                            />
                        </div>

                        <label className="block text-xs font-bold text-slate-500 uppercase mb-3">Tipo de Contenido</label>
                        <div className="grid grid-cols-4 gap-3 mb-6">
                            {[
                                { id: 'text', icon: Type, label: 'Texto' },
                                { id: 'audio', icon: Mic, label: 'Audio' },
                                { id: 'video', icon: Video, label: 'Video' },
                                { id: 'image', icon: ImageIcon, label: 'Imagen' }
                            ].map((type) => (
                                <button 
                                    key={type.id}
                                    onClick={() => setNewHotspotType(type.id as any)}
                                    className={`flex flex-col items-center justify-center gap-2 p-3 rounded-xl border transition-all ${newHotspotType === type.id ? 'bg-brand-50 border-brand-500 text-brand-700 ring-1 ring-brand-500' : 'bg-slate-50 border-slate-200 text-slate-500 hover:bg-white hover:shadow-sm'}`}
                                >
                                    <type.icon className="w-6 h-6" />
                                    <span className="text-[10px] font-bold uppercase">{type.label}</span>
                                </button>
                            ))}
                        </div>

                        <div className="mb-6">
                             <label className="block text-xs font-bold text-slate-500 uppercase mb-2">
                                 {newHotspotType === 'text' ? 'Contenido del Texto' : 'URL del Archivo'}
                             </label>
                             {newHotspotType === 'text' ? (
                                 <textarea 
                                    rows={4}
                                    value={newHotspotContent}
                                    onChange={(e) => setNewHotspotContent(e.target.value)}
                                    className="w-full border border-slate-300 rounded-xl px-4 py-3 text-slate-900 focus:ring-2 focus:ring-brand-500 outline-none resize-none"
                                    placeholder="Escribe la información aquí..."
                                 />
                             ) : (
                                 <input 
                                    type="text"
                                    value={newHotspotContent}
                                    onChange={(e) => setNewHotspotContent(e.target.value)}
                                    className="w-full border border-slate-300 rounded-xl px-4 py-3 text-slate-900 focus:ring-2 focus:ring-brand-500 outline-none"
                                    placeholder={`https://ejemplo.com/archivo.${newHotspotType === 'image' ? 'jpg' : 'mp3'}`}
                                 />
                             )}
                        </div>

                        <button 
                            onClick={confirmHotspotCreation}
                            className="w-full bg-slate-900 text-white py-4 rounded-xl font-bold hover:bg-brand-600 transition-colors shadow-lg"
                        >
                            Añadir
                        </button>
                    </div>
                </div>
            </div>
        )}

        {showSettings && (
            <div className="fixed inset-0 z-[100] bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in">
                <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden animate-fade-in-up ring-1 ring-black/5">
                    <div className="flex justify-between items-center p-4 border-b border-slate-100 bg-slate-50/50">
                        <h3 className="font-bold text-slate-800 flex items-center gap-2">
                            <Settings className="w-4 h-4 text-brand-600" /> Configuración
                        </h3>
                        <button onClick={() => setShowSettings(false)} className="text-slate-400 hover:text-slate-600 transition-colors p-1">
                            <X className="w-5 h-5" />
                        </button>
                    </div>
                    <div className="p-6 space-y-4">
                        <div>
                            <label className="block text-xs font-bold text-slate-500 uppercase mb-1.5">Categoría</label>
                            <select 
                                value={routeCategory} 
                                onChange={(e) => setRouteCategory(e.target.value as CategoryType)}
                                className="w-full border border-slate-300 rounded-xl px-4 py-2.5 text-sm bg-white focus:ring-2 focus:ring-brand-500 outline-none transition-all"
                            >
                                {Object.values(CategoryType).map(cat => (
                                    <option key={cat} value={cat}>{cat}</option>
                                ))}
                            </select>
                        </div>
                        <div>
                            <label className="block text-xs font-bold text-slate-500 uppercase mb-1.5">Descripción</label>
                            <textarea 
                                value={routeDescription}
                                onChange={(e) => setRouteDescription(e.target.value)}
                                rows={4}
                                placeholder="Describe de qué trata esta ruta..."
                                className="w-full border border-slate-300 rounded-xl px-4 py-2.5 text-sm focus:ring-2 focus:ring-brand-500 outline-none resize-none transition-all"
                            />
                        </div>
                    </div>
                    <div className="p-4 bg-slate-50 border-t border-slate-100 flex justify-end">
                        <button onClick={() => setShowSettings(false)} className="bg-slate-900 text-white px-6 py-2 rounded-lg font-bold text-sm hover:bg-slate-800 transition-colors">
                            Listo
                        </button>
                    </div>
                </div>
            </div>
        )}
      </div>
    </>
  );
};