import React, { useMemo, useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { RouteModel, GeoLocation, CategoryType } from '../types';
import { CATEGORY_METADATA } from '../constants';
import { 
  ArrowRight, Compass, MapPin, Clock, Star, Map as MapIcon, 
  ChevronRight, ChevronLeft, Filter, Sparkles, 
  Utensils, Camera, Mountain, Palette, Flag, Activity, Building, Scroll, Moon, Key, Sun
} from 'lucide-react';
import { SEOHelmet } from '../components/SEOHelmet';
import { ScenicMap } from '../components/ScenicMap';

interface HomeProps {
  location: GeoLocation;
  routes: RouteModel[];
  addToCart: (route: RouteModel) => void;
}

const CATEGORY_ICONS: Record<string, any> = {
  'Todas': Compass,
  [CategoryType.TURISMO]: MapIcon,
  [CategoryType.GASTRONOMIA]: Utensils,
  [CategoryType.FOTOGRAFIA]: Camera,
  [CategoryType.NATURALEZA]: Mountain,
  [CategoryType.ARTE]: Palette,
  [CategoryType.YINCANAS]: Flag,
  [CategoryType.FITNESS]: Activity,
  [CategoryType.ARQUITECTURA]: Building,
  [CategoryType.HISTORIA]: Scroll,
  [CategoryType.VIDA_NOCTURNA]: Moon,
  [CategoryType.OCULTOS]: Key,
  [CategoryType.ESPIRITUAL]: Sun,
};

export const Home: React.FC<HomeProps> = ({ location, routes, addToCart }) => {
  const navigate = useNavigate();
  const [activeCategory, setActiveCategory] = useState<string>('Todas');
  const [activeIndex, setActiveIndex] = useState(0);
  const scrollRef = useRef<HTMLDivElement>(null);
  const categoryScrollRef = useRef<HTMLDivElement>(null);

  const filteredRoutes = useMemo(() => {
    let base = activeCategory === 'Todas' ? routes : routes.filter(r => r.category === activeCategory);
    return base.slice(0, 20);
  }, [routes, activeCategory]);

  const activeRoute = filteredRoutes[activeIndex] || filteredRoutes[0];

  const handleScroll = (e: React.UIEvent<HTMLDivElement>) => {
    const scrollLeft = e.currentTarget.scrollLeft;
    const itemWidth = window.innerWidth * 0.22 + 12; 
    const newIndex = Math.round(scrollLeft / itemWidth);
    if (newIndex !== activeIndex && newIndex < filteredRoutes.length) {
      setActiveIndex(newIndex);
    }
  };

  useEffect(() => {
    setActiveIndex(0);
    if (scrollRef.current) scrollRef.current.scrollLeft = 0;
  }, [activeCategory]);

  return (
    <>
      <SEOHelmet 
        title={`Marketplace de Rutas en ${location.name}`} 
        description={`Compra y vende las mejores rutas digitales ilustradas en ${location.name} con Wanderlust.`} 
      />
      
      <div className="flex flex-col h-[calc(100vh-64px)] md:h-[calc(100vh-80px)] overflow-hidden bg-slate-50">
        
        <div className="relative h-[66%] md:h-[65%] w-full overflow-hidden">
          <ScenicMap 
            points={activeRoute?.points || []}
            baseLocation={location}
            activePointId={activeRoute?.points[0]?.id}
            className="w-full h-full"
            cityImage={activeRoute?.thumbnail}
            showTitle={false}
          />
          
          {/* CATEGORÍAS FLOTANTES COMPACTADAS */}
          <div className="absolute inset-x-0 bottom-8 z-40 flex justify-center px-4">
             <div 
               ref={categoryScrollRef}
               className="flex items-center gap-2.5 overflow-x-auto no-scrollbar py-1.5 px-4 bg-white/10 backdrop-blur-md rounded-full border border-white/20 shadow-2xl max-w-full md:max-w-max snap-x"
             >
                {Object.keys(CATEGORY_ICONS).map((cat) => {
                  const Icon = CATEGORY_ICONS[cat];
                  const isActive = activeCategory === cat;
                  return (
                    <button 
                      key={cat}
                      onClick={() => setActiveCategory(cat)}
                      className={`
                        shrink-0 snap-center w-9 h-9 md:w-11 md:h-11 rounded-full flex items-center justify-center transition-all duration-300 relative group
                        ${isActive 
                          ? 'bg-brand-500 text-white scale-110 shadow-glow-sm ring-2 ring-white' 
                          : 'bg-white/90 text-slate-500 hover:bg-white hover:text-brand-600 shadow-md'}
                      `}
                    >
                      <Icon className={`${isActive ? 'w-4 h-4 md:w-5 md:h-5' : 'w-3.5 h-3.5 md:w-4 md:h-4'}`} />
                      
                      <span className={`
                        absolute -top-9 bg-slate-900 text-white text-[9px] font-black px-2 py-0.5 rounded-md whitespace-nowrap transition-all duration-300
                        ${isActive ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-2 pointer-events-none group-hover:opacity-100 group-hover:translate-y-0'}
                      `}>
                        {cat}
                      </span>
                    </button>
                  );
                })}
             </div>
          </div>

          <div className="absolute inset-x-0 top-4 p-4 z-30 pointer-events-none">
            <div className="max-w-7xl mx-auto flex justify-center">
               <div className="bg-slate-900/90 backdrop-blur-xl px-4 py-1.5 rounded-full shadow-2xl border border-white/10 pointer-events-auto flex items-center gap-3 animate-fade-in-up">
                  <div className="bg-brand-500 p-1.5 rounded-full">
                     <Sparkles className="w-2.5 h-2.5 text-white" />
                  </div>
                  <h2 className="text-[10px] md:text-xs font-black text-white tracking-tight truncate max-w-[150px] md:max-w-none uppercase">
                    {activeRoute?.title}
                  </h2>
                  <div className="w-px h-2.5 bg-white/20"></div>
                  <span className="text-[9px] font-bold text-brand-300">
                    {activeRoute?.price === 0 ? 'Gratis' : `$${activeRoute?.price?.toFixed(2)}`}
                  </span>
               </div>
            </div>
          </div>
        </div>

        <div className="relative h-[34%] md:h-[35%] bg-white flex flex-col pt-4 md:pt-6 rounded-t-[2rem] md:rounded-t-[2.5rem] -mt-8 z-40 shadow-[0_-20px_50px_rgba(0,0,0,0.1)] border-t border-slate-100">
          
          <div className="px-6 mb-2 md:mb-3 flex justify-between items-center shrink-0">
             <div>
                <h3 className="text-xs md:text-lg font-black text-slate-900 tracking-tight flex items-center gap-2 uppercase">
                  Marketplace <span className="text-[8px] md:text-[10px] bg-slate-100 text-slate-500 px-1.5 py-0.5 rounded font-bold">{activeCategory}</span>
                </h3>
             </div>
             <button onClick={() => navigate('/categories')} className="text-[9px] font-black text-brand-600 uppercase tracking-widest hover:underline">Explorar Todo</button>
          </div>

          <div 
            ref={scrollRef}
            onScroll={handleScroll}
            className="flex-grow flex items-center gap-3 px-6 overflow-x-auto snap-x snap-mandatory no-scrollbar pb-6"
          >
            {filteredRoutes.length === 0 ? (
              <div className="w-full text-center py-4 text-slate-400 text-xs font-bold italic">No hay rutas en esta categoría</div>
            ) : (
              filteredRoutes.map((route, idx) => (
                <div 
                  key={route.id}
                  onClick={() => { 
                    setActiveIndex(idx); 
                    scrollRef.current?.scrollTo({ left: idx * (window.innerWidth * 0.22 + 12), behavior: 'smooth' }); 
                  }}
                  className={`
                    flex-shrink-0 w-[24vw] md:w-[260px] aspect-[3/4] md:aspect-video rounded-xl md:rounded-[2rem] overflow-hidden snap-center cursor-pointer transition-all duration-500 relative group
                    ${activeIndex === idx ? 'ring-2 md:ring-4 ring-brand-500 shadow-xl scale-105 z-10' : 'opacity-60 grayscale-[30%]'}
                  `}
                >
                  <img src={route.thumbnail} className="absolute inset-0 w-full h-full object-cover" alt="" />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-slate-900/10 to-transparent" />
                  
                  <div className="absolute top-1.5 right-1.5 md:top-2 md:right-2">
                    <span className="bg-white/95 backdrop-blur-sm text-slate-900 text-[7px] md:text-[9px] font-black px-1.5 py-0.5 rounded shadow-sm">
                      {route.price === 0 ? 'Gratis' : `$${route.price.toFixed(2)}`}
                    </span>
                  </div>

                  <div className="absolute inset-0 p-2 md:p-4 flex flex-col justify-end text-white">
                    <h4 className="font-bold text-[7px] md:text-xs leading-tight mb-1 truncate uppercase tracking-tight">{route.title}</h4>
                    <div className="flex items-center justify-between">
                       <div className="flex items-center gap-0.5">
                          <Star className="w-1.5 h-1.5 md:w-2.5 md:h-2.5 text-yellow-400 fill-yellow-400" />
                          <span className="text-[6px] md:text-[9px] font-bold">{route.rating.toFixed(1)}</span>
                       </div>
                       <button 
                        onClick={(e) => { e.stopPropagation(); navigate(`/route/${route.id}`); }}
                        className="w-4 h-4 md:w-7 md:h-7 bg-brand-500 text-white rounded md:rounded-lg flex items-center justify-center hover:bg-brand-600 transition-all"
                       >
                        <ArrowRight className="w-2.5 h-2.5 md:w-4 md:h-4" />
                       </button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        <style>{`
        .no-scrollbar::-webkit-scrollbar { display: none; }
        .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
      `}</style>
    </>
  );
};