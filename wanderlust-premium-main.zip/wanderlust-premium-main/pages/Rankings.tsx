
import React from 'react';
import { RouteModel, GeoLocation } from '../types';
import { SEOHelmet } from '../components/SEOHelmet';
import { RouteCard } from '../components/RouteCard';
import { Trophy, Medal, TrendingUp, Users, ArrowRight } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface RankingsProps {
  routes: RouteModel[];
  location: GeoLocation;
  addToCart: (route: RouteModel) => void;
}

export const Rankings: React.FC<RankingsProps> = ({ routes, location, addToCart }) => {
  const navigate = useNavigate();
  const topRoutes = [...routes].sort((a, b) => b.rating - a.rating).slice(0, 5);
  const trendingRoutes = [...routes].sort((a, b) => b.reviews - a.reviews).slice(0, 5);

  const formatPrice = (price: number) => price === 0 ? 'Gratis' : `$${price.toFixed(2)}`;

  return (
    <>
      <SEOHelmet title={`Rankings en ${location.name}`} description="Descubre las rutas más populares y mejor valoradas." />
      
      <div className="bg-slate-50 min-h-screen pb-20">
        <div className="bg-ui-900 py-16 text-center text-white relative overflow-hidden">
            <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-10"></div>
            <h1 className="text-4xl font-bold mb-4 relative z-10 flex items-center justify-center gap-3">
               <Trophy className="text-yellow-400 w-10 h-10" /> Hall of Fame
            </h1>
            <p className="text-slate-400 max-w-xl mx-auto relative z-10">
               Las experiencias mejor valoradas por la comunidad de viajeros en {location.name}.
            </p>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-8 relative z-20">
            
            {/* Top 1 Badge */}
            <div className="bg-white rounded-[2.5rem] p-8 shadow-xl border border-slate-100 mb-12 flex flex-col md:flex-row items-center gap-8">
               <div className="w-full md:w-1/3 relative">
                  <div className="absolute -top-4 -left-4 bg-yellow-400 text-yellow-900 font-bold px-4 py-2 rounded-full shadow-lg flex items-center gap-2 z-10">
                     <Medal className="w-5 h-5" /> #1 DE LA SEMANA
                  </div>
                  <img src={topRoutes[0]?.thumbnail} className="w-full aspect-square object-cover rounded-[2rem] shadow-md" alt="Top 1" />
               </div>
               <div className="w-full md:w-2/3">
                  <div className="flex items-center gap-2 text-brand-600 font-bold text-sm uppercase mb-2">
                     <TrendingUp className="w-4 h-4" /> Tendencia Absoluta
                  </div>
                  <h2 className="text-3xl md:text-4xl font-black text-slate-900 mb-4 tracking-tighter">{topRoutes[0]?.title}</h2>
                  <p className="text-slate-600 text-lg mb-6 leading-relaxed">{topRoutes[0]?.description}</p>
                  <div className="flex items-center gap-6 mb-8">
                     <div className="flex items-center gap-2">
                        <Users className="w-5 h-5 text-slate-400" />
                        <span className="font-bold text-slate-700">{topRoutes[0] ? topRoutes[0].reviews * 12 : 0} viajeros</span>
                     </div>
                     <div className="flex items-center gap-2">
                        <span className="bg-green-100 text-green-700 px-3 py-1 rounded-full text-[10px] font-black uppercase">98% Satisfacción</span>
                     </div>
                  </div>
                  <div className="flex items-center gap-4">
                     <button onClick={() => navigate(`/route/${topRoutes[0]?.id}`)} className="bg-brand-600 hover:bg-brand-700 text-white px-8 py-3.5 rounded-2xl font-black shadow-lg shadow-brand-200 transition-all">
                        Ver Ruta Completa
                     </button>
                     <span className="text-2xl font-black text-slate-900">
                        {topRoutes[0] ? formatPrice(topRoutes[0].price) : ''}
                     </span>
                  </div>
               </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
               {/* Best Rated Column */}
               <div>
                  <h3 className="text-2xl font-black text-slate-900 mb-6 flex items-center gap-2 tracking-tight">
                     <Medal className="text-brand-500 w-6 h-6" /> Mejor Valoradas
                  </h3>
                  <div className="space-y-4">
                     {topRoutes.map((route, idx) => (
                        <div key={route.id} className="group flex bg-white p-4 rounded-2xl shadow-sm border border-slate-100 items-center gap-4 hover:shadow-md transition-all">
                           <span className="text-3xl font-black text-slate-100 w-10 text-center group-hover:text-brand-100 transition-colors">{idx + 1}</span>
                           <img src={route.thumbnail} className="w-16 h-16 rounded-xl object-cover" alt="" />
                           <div className="flex-grow">
                              <h4 className="font-bold text-slate-900 line-clamp-1 group-hover:text-brand-600 transition-colors">{route.title}</h4>
                              <div className="flex items-center justify-between mt-1">
                                 <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">{route.category.split(' ')[0]}</p>
                                 <div className="flex items-center gap-1 text-yellow-500 text-sm font-black">
                                    ★ {route.rating.toFixed(1)}
                                 </div>
                              </div>
                           </div>
                           <button onClick={() => navigate(`/route/${route.id}`)} className="p-3 bg-slate-50 hover:bg-brand-500 hover:text-white rounded-xl transition-all">
                              <ArrowRight className="w-5 h-5" />
                           </button>
                        </div>
                     ))}
                  </div>
               </div>

               {/* Most Popular Column */}
               <div>
                  <h3 className="text-2xl font-black text-slate-900 mb-6 flex items-center gap-2 tracking-tight">
                     <TrendingUp className="text-blue-500 w-6 h-6" /> Más Vendidas
                  </h3>
                  <div className="space-y-4">
                     {trendingRoutes.map((route, idx) => (
                        <div key={route.id} className="group flex bg-white p-4 rounded-2xl shadow-sm border border-slate-100 items-center gap-4 hover:shadow-md transition-all">
                           <span className="text-3xl font-black text-slate-100 w-10 text-center group-hover:text-blue-100 transition-colors">{idx + 1}</span>
                           <img src={route.thumbnail} className="w-16 h-16 rounded-xl object-cover" alt="" />
                           <div className="flex-grow">
                              <h4 className="font-bold text-slate-900 line-clamp-1 group-hover:text-blue-600 transition-colors">{route.title}</h4>
                              <div className="flex items-center justify-between mt-1">
                                 <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">{route.reviews} reseñas</p>
                                 <span className="text-sm font-black text-slate-900">
                                    {formatPrice(route.price)}
                                 </span>
                              </div>
                           </div>
                           <button onClick={() => navigate(`/route/${route.id}`)} className="p-3 bg-slate-50 hover:bg-blue-500 hover:text-white rounded-xl transition-all">
                              <ArrowRight className="w-5 h-5" />
                           </button>
                        </div>
                     ))}
                  </div>
               </div>
            </div>

        </div>
      </div>
    </>
  );
};
