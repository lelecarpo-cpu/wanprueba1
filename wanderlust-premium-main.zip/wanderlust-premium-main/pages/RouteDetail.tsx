
import React, { useMemo, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { RouteModel } from '../types';
import { 
  Star, Clock, MapPin, ArrowLeft, ShoppingCart, 
  Play, Lock
} from 'lucide-react';
import { ScenicMap } from '../components/ScenicMap';
import { SEOHelmet } from '../components/SEOHelmet';
import { JourneyPlayer } from '../components/JourneyPlayer';

interface RouteDetailProps {
  routes: RouteModel[];
  addToCart: (route: RouteModel) => void;
  purchasedRoutes: RouteModel[];
}

export const RouteDetail: React.FC<RouteDetailProps> = ({ routes, addToCart, purchasedRoutes }) => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [isPlaying, setIsPlaying] = useState(false);

  const route = useMemo(() => routes.find(r => r.id === id), [routes, id]);
  const isPurchased = useMemo(() => purchasedRoutes.some(r => r.id === id), [purchasedRoutes, id]);

  if (!route) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="text-center bg-white p-12 rounded-[2rem] shadow-xl border border-slate-100">
          <h2 className="text-2xl font-bold mb-4 text-slate-900">Ruta no encontrada</h2>
          <button onClick={() => navigate('/')} className="bg-brand-600 text-white px-8 py-3 rounded-xl font-bold">Volver</button>
        </div>
      </div>
    );
  }

  const parentPoints = route.points || [];

  if (isPlaying && isPurchased) {
    return <JourneyPlayer route={route} onClose={() => setIsPlaying(false)} />;
  }

  return (
    <>
      <SEOHelmet title={route.title} description={route.description} />
      
      <div className="bg-[#F8FAFC] min-h-screen">
        {/* Navbar Simplificado */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 flex justify-between items-center z-10 relative">
           <button onClick={() => navigate(-1)} className="flex items-center gap-2 bg-white px-4 py-2 rounded-full shadow-sm border border-slate-200 text-slate-600 font-bold hover:bg-slate-50 transition-colors">
              <ArrowLeft className="w-4 h-4" /> Volver
           </button>
           <button onClick={() => addToCart(route)} className="p-3 bg-white rounded-full shadow-sm border border-slate-200 text-slate-600 hover:text-brand-600 transition-colors">
              <ShoppingCart className="w-5 h-5" />
           </button>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-12">
           <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
              
              {/* Columna Izquierda: Info básica */}
              <div className="lg:col-span-4 space-y-6">
                 <div>
                    <span className="bg-brand-100 text-brand-700 font-black tracking-widest text-[10px] uppercase px-3 py-1 rounded-full mb-4 inline-block">{route.category}</span>
                    <h1 className="text-4xl md:text-5xl font-black text-slate-900 mb-4 tracking-tighter leading-[0.9]">{route.title}</h1>
                    <p className="text-slate-500 font-medium leading-relaxed">{route.description}</p>
                 </div>

                 <div className="flex gap-3 text-sm font-bold text-slate-600">
                     <div className="flex items-center gap-1.5 bg-white px-3 py-2 rounded-lg border border-slate-200 shadow-sm">
                        <Clock className="w-4 h-4 text-brand-500" /> {route.durationMin}m
                     </div>
                     <div className="flex items-center gap-1.5 bg-white px-3 py-2 rounded-lg border border-slate-200 shadow-sm">
                        <MapPin className="w-4 h-4 text-brand-500" /> {route.distanceKm}km
                     </div>
                     <div className="flex items-center gap-1.5 bg-white px-3 py-2 rounded-lg border border-slate-200 shadow-sm">
                        <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" /> {route.rating.toFixed(1)}
                     </div>
                 </div>

                 <div className="pt-6 border-t border-slate-200">
                    <div className="flex items-center justify-between mb-4">
                        <span className="text-xs font-black uppercase text-slate-400 tracking-widest">Precio Total</span>
                        <span className="text-3xl font-black text-slate-900">${route.price}</span>
                    </div>
                    {isPurchased ? (
                       <button onClick={() => setIsPlaying(true)} className="w-full bg-slate-900 text-white py-4 rounded-2xl font-black shadow-xl hover:bg-slate-800 transition-all flex items-center justify-center gap-2">
                          <Play className="w-5 h-5" /> Comenzar Aventura
                       </button>
                    ) : (
                       <button onClick={() => addToCart(route)} className="w-full bg-brand-500 text-white py-4 rounded-2xl font-black shadow-lg shadow-brand-500/30 hover:bg-brand-600 transition-all flex items-center justify-center gap-2">
                          <Lock className="w-4 h-4" /> Comprar Ruta
                       </button>
                    )}
                 </div>
              </div>

              {/* Columna Derecha: VISUALIZADOR DE MAPA (Principal) */}
              <div className="lg:col-span-8 h-[600px] lg:h-[700px]">
                 <div className="w-full h-full bg-white rounded-[3rem] shadow-2xl border-4 border-white overflow-hidden relative group ring-1 ring-slate-100">
                    <ScenicMap 
                      points={parentPoints} 
                      baseLocation={route.location} 
                      className="w-full h-full"
                    />
                    
                    {/* Overlay si no está comprado (Opcional, para incitar la compra) */}
                    {!isPurchased && (
                       <div className="absolute inset-0 bg-white/30 backdrop-blur-[2px] z-30 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity duration-500 pointer-events-none">
                          <div className="bg-slate-900 text-white px-6 py-3 rounded-full font-bold shadow-2xl transform translate-y-4 group-hover:translate-y-0 transition-transform">
                             Vista Previa Interactiva
                          </div>
                       </div>
                    )}
                 </div>
              </div>

           </div>
        </div>
      </div>
    </>
  );
};
