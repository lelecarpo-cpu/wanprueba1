
import React, { useState, useEffect } from 'react';
import { RouteModel, GeoLocation } from '../types';
import { SEOHelmet } from '../components/SEOHelmet';
import { RouteCard } from '../components/RouteCard';
import { User, Settings, Heart, Map, Download, LogOut, CreditCard, PenTool, PlusCircle, FileText, UploadCloud, Edit } from 'lucide-react';
import { AVAILABLE_LOCATIONS } from '../constants';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';

interface UserProfileProps {
  location: GeoLocation;
  purchasedRoutes: RouteModel[];
  favorites: RouteModel[];
  createdRoutes: RouteModel[];
}

type TabType = 'routes' | 'created' | 'favorites' | 'settings' | 'downloads';

export const UserProfile: React.FC<UserProfileProps> = ({ location, purchasedRoutes, favorites, createdRoutes }) => {
  const [activeTab, setActiveTab] = useState<TabType>('routes');
  const navigate = useNavigate();
  const { user, signOut } = useAuth();

  useEffect(() => {
    if (!user) {
        navigate('/auth');
    }
  }, [user, navigate]);

  const handleLogout = async () => {
    try {
        await signOut();
        // We let the useEffect above handle the redirection to /auth once user state is null
    } catch (error) {
        console.error("Logout failed", error);
        navigate('/'); // Fallback
    }
  };

  const handleEditRoute = (route: RouteModel) => {
    navigate('/create', { state: { editRoute: route } });
  };

  if (!user) return null;

  return (
    <>
      <SEOHelmet title="Mi Perfil" description="Gestiona tus rutas y configuración personal." />
      
      <div className="min-h-screen bg-slate-50">
        <div className="bg-white border-b border-slate-200">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 md:py-12">
            <div className="flex flex-col md:flex-row items-center md:items-start gap-6">
              <div className="relative">
                <div className="w-24 h-24 md:w-32 md:h-32 rounded-full border-4 border-white shadow-lg bg-gradient-to-br from-brand-100 to-indigo-100 flex items-center justify-center text-brand-600 text-4xl font-bold uppercase">
                    {user.email?.substring(0, 2)}
                </div>
                <div className="absolute bottom-1 right-1 bg-green-500 w-5 h-5 rounded-full border-2 border-white"></div>
              </div>
              <div className="text-center md:text-left flex-grow">
                <h1 className="text-3xl font-bold text-slate-900">
                    {user.user_metadata?.full_name || user.email?.split('@')[0] || 'Usuario Explorador'}
                </h1>
                <p className="text-slate-500">{user.email} • {location.name}</p>
                <div className="flex flex-wrap justify-center md:justify-start gap-3 mt-4">
                  <span className="px-3 py-1 bg-brand-50 text-brand-700 text-xs font-bold rounded-full uppercase tracking-wider">Miembro</span>
                  <span className="px-3 py-1 bg-slate-100 text-slate-700 text-xs font-bold rounded-full uppercase tracking-wider">{purchasedRoutes.length} Compradas</span>
                  <span className="px-3 py-1 bg-purple-100 text-purple-700 text-xs font-bold rounded-full uppercase tracking-wider">{createdRoutes.length} Creadas</span>
                </div>
              </div>
              <button 
                type="button"
                onClick={handleLogout}
                className="flex items-center gap-2 text-slate-500 hover:text-red-600 transition-colors px-4 py-2 rounded-lg border border-transparent hover:bg-red-50 hover:border-red-100 cursor-pointer"
              >
                <LogOut className="w-4 h-4" />
                <span className="font-semibold text-sm">Cerrar Sesión</span>
              </button>
            </div>
          </div>
          
          {/* Tabs */}
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-6">
            <div className="flex space-x-8 overflow-x-auto">
              {['routes', 'created', 'favorites', 'downloads', 'settings'].map((tab) => (
                  <button 
                    key={tab}
                    onClick={() => setActiveTab(tab as TabType)}
                    className={`pb-4 px-2 border-b-2 font-medium text-sm whitespace-nowrap flex items-center gap-2 ${activeTab === tab ? 'border-brand-600 text-brand-600' : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300'}`}
                  >
                    {tab === 'routes' && <Map className="w-4 h-4" />}
                    {tab === 'created' && <PenTool className="w-4 h-4" />}
                    {tab === 'favorites' && <Heart className="w-4 h-4" />}
                    {tab === 'downloads' && <Download className="w-4 h-4" />}
                    {tab === 'settings' && <Settings className="w-4 h-4" />}
                    {tab === 'routes' ? 'Mis Compras' : tab.charAt(0).toUpperCase() + tab.slice(1)}
                  </button>
              ))}
            </div>
          </div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          
          {activeTab === 'routes' && (
            <div>
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-xl font-bold text-slate-900">Rutas Adquiridas</h2>
              </div>
              {purchasedRoutes.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {purchasedRoutes.map(route => <RouteCard key={route.id} route={route} compact />)}
                </div>
              ) : (
                <div className="text-center py-16 bg-white rounded-2xl border border-dashed border-slate-300">
                  <Map className="w-12 h-12 text-slate-300 mx-auto mb-4" />
                  <p className="text-slate-500 font-medium">Aún no has comprado ninguna ruta.</p>
                  <button onClick={() => navigate('/')} className="mt-4 px-6 py-2 bg-brand-600 text-white rounded-full text-sm font-bold hover:bg-brand-700">Explorar ahora</button>
                </div>
              )}
            </div>
          )}

          {activeTab === 'created' && (
            <div>
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-xl font-bold text-slate-900">Mis Creaciones</h2>
                <button onClick={() => navigate('/create')} className="flex items-center gap-2 bg-slate-900 text-white px-4 py-2 rounded-lg text-sm font-bold hover:bg-slate-800 transition-colors">
                    <PlusCircle className="w-4 h-4" /> Nueva Ruta
                </button>
              </div>
              {createdRoutes.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {createdRoutes.map(route => (
                    <div key={route.id} className="relative group">
                        <div className={`absolute top-2 left-2 z-10 text-[10px] font-bold px-2 py-1 rounded-md border flex items-center gap-1 shadow-sm backdrop-blur-sm ${route.status === 'published' ? 'bg-green-100/90 text-green-800 border-green-200' : 'bg-amber-100/90 text-amber-800 border-amber-200'}`}>
                            {route.status === 'published' ? <UploadCloud className="w-3 h-3" /> : <FileText className="w-3 h-3" />}
                            {route.status === 'published' ? 'PUBLICADO' : 'BORRADOR'}
                        </div>
                        <div className="opacity-75 transition-opacity hover:opacity-100"><RouteCard route={route} compact /></div>
                        <div className="absolute top-2 right-2 z-10 opacity-0 group-hover:opacity-100 transition-opacity">
                             <button onClick={(e) => { e.stopPropagation(); handleEditRoute(route); }} className="bg-white text-slate-700 p-2 rounded-full shadow-lg hover:bg-brand-600 hover:text-white transition-colors" title="Editar Ruta"><Edit className="w-4 h-4" /></button>
                        </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-16 bg-white rounded-2xl border border-dashed border-slate-300">
                  <PenTool className="w-12 h-12 text-slate-300 mx-auto mb-4" />
                  <p className="text-slate-500 font-medium">No has creado ninguna ruta todavía.</p>
                  <button onClick={() => navigate('/create')} className="mt-4 px-6 py-2 bg-brand-600 text-white rounded-full text-sm font-bold hover:bg-brand-700">Crear mi primera ruta</button>
                </div>
              )}
            </div>
          )}

          {activeTab === 'favorites' && (
             <div>
                <h2 className="text-xl font-bold text-slate-900 mb-6">Mis Favoritos</h2>
                {favorites.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {favorites.map(route => <RouteCard key={route.id} route={route} />)}
                  </div>
                ) : (
                  <div className="text-center py-16 bg-white rounded-2xl border border-dashed border-slate-300">
                    <Heart className="w-12 h-12 text-slate-300 mx-auto mb-4" />
                    <p className="text-slate-500 font-medium">No tienes rutas favoritas guardadas.</p>
                  </div>
                )}
             </div>
          )}

          {activeTab === 'downloads' && (
             <div className="bg-white rounded-2xl border border-slate-100 p-8">
                <h2 className="text-xl font-bold text-slate-900 mb-4">Modo Offline</h2>
                <p className="text-slate-500 mb-8 max-w-2xl">Descarga tus rutas para acceder a mapas, audio guías y contenido multimedia sin conexión a internet.</p>
                <div className="space-y-4">
                  {purchasedRoutes.slice(0, 2).map((route, idx) => (
                    <div key={route.id} className="flex items-center justify-between p-4 bg-slate-50 rounded-xl border border-slate-100">
                       <div className="flex items-center gap-4">
                          <img src={route.thumbnail} className="w-12 h-12 rounded-lg object-cover" alt="" />
                          <div>
                             <h4 className="font-bold text-slate-900">{route.title}</h4>
                             <span className="text-xs text-slate-500">245 MB</span>
                          </div>
                       </div>
                       <button className={`px-4 py-2 rounded-lg text-sm font-bold flex items-center gap-2 ${idx === 0 ? 'bg-green-100 text-green-700' : 'bg-slate-200 text-slate-600'}`}>
                          {idx === 0 ? <CheckIcon /> : <Download className="w-4 h-4" />}
                          {idx === 0 ? 'Descargado' : 'Descargar'}
                       </button>
                    </div>
                  ))}
                  {purchasedRoutes.length === 0 && <p className="text-sm text-slate-400 italic">Compra una ruta para poder descargarla.</p>}
                </div>
             </div>
          )}

          {activeTab === 'settings' && (
             <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div className="md:col-span-2 space-y-6">
                   <div className="bg-white rounded-2xl border border-slate-100 p-6">
                      <h3 className="text-lg font-bold text-slate-900 mb-4 flex items-center gap-2"><User className="w-5 h-5 text-brand-600" /> Información Personal</h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                         <div>
                            <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Email</label>
                            <input type="email" value={user.email} disabled className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm bg-slate-50 cursor-not-allowed" />
                         </div>
                         <div className="md:col-span-2">
                             <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Bio</label>
                             <textarea rows={3} className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm" placeholder="Cuéntanos sobre ti..."></textarea>
                         </div>
                      </div>
                      <div className="mt-4 text-right"><button className="bg-brand-600 text-white px-4 py-2 rounded-lg font-bold text-sm">Guardar Cambios</button></div>
                   </div>
                   <div className="bg-white rounded-2xl border border-slate-100 p-6">
                      <h3 className="text-lg font-bold text-slate-900 mb-4 flex items-center gap-2"><Settings className="w-5 h-5 text-brand-600" /> Preferencias</h3>
                      <div className="space-y-4">
                         <div>
                            <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Ubicación Predeterminada</label>
                            <select className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm">
                               {AVAILABLE_LOCATIONS.map(loc => <option key={loc.name} value={loc.name}>{loc.name}</option>)}
                            </select>
                         </div>
                      </div>
                   </div>
                </div>
                <div className="md:col-span-1">
                   <div className="bg-white rounded-2xl border border-slate-100 p-6">
                      <h3 className="text-lg font-bold text-slate-900 mb-4 flex items-center gap-2"><CreditCard className="w-5 h-5 text-brand-600" /> Método de Pago</h3>
                      <div className="flex items-center gap-3 p-3 bg-slate-50 rounded-lg border border-slate-200 mb-4">
                         <div className="w-10 h-6 bg-slate-800 rounded flex items-center justify-center text-white text-[10px] font-bold">VISA</div>
                         <div className="flex-grow"><p className="text-xs font-bold text-slate-900">•••• 4242</p><p className="text-[10px] text-slate-500">Expira 12/25</p></div>
                      </div>
                      <button className="w-full border border-dashed border-slate-300 text-slate-500 hover:border-brand-500 hover:text-brand-600 py-2 rounded-lg text-sm font-bold transition-colors">+ Añadir tarjeta</button>
                   </div>
                </div>
             </div>
          )}

        </div>
      </div>
    </>
  );
};

const CheckIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>
);
