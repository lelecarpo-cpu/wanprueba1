

export enum CategoryType {
  YINCANAS = 'Yincanas y Juegos',
  TURISMO = 'Turismo y city tours',
  NATURALEZA = 'Naturaleza y senderismo',
  FITNESS = 'Fitness y rutas deportivas',
  GASTRONOMIA = 'Gastronomía',
  FOTOGRAFIA = 'Fotografía y spots icónicos',
  ARTE = 'Arte y cultura',
  ARQUITECTURA = 'Arquitectura',
  HISTORIA = 'Rutas históricas',
  VIDA_NOCTURNA = 'Vida nocturna',
  AVENTURA = 'Aventura y deportes extremos',
  OCULTOS = 'Lugares ocultos / secretos',
  ESPIRITUAL = 'Espirituales y wellness',
}

export interface GeoLocation {
  lat: number;
  lng: number;
  name: string;
}

export interface RoutePoint {
  id: string;
  parentId?: string; // Links this point to a main map point
  lat: number;
  lng: number;
  title: string;
  description: string;
  mediaType: 'text' | 'image' | 'video' | 'audio' | 'none'; // Updated types
  mediaUrl?: string;
  durationMin: number;
  streetViewConfig?: {
    heading: number;
    pitch: number;
    zoom?: number; // Added zoom property
  };
  streetViewTarget?: {
    x: number;
    y: number;
  };
  snapshotUrl?: string; // New field for static street view capture
}

export interface Creator {
  id: string;
  name: string;
  avatar: string;
  rating: number;
  reviewCount: number;
  routesCount: number;
  bio: string;
  badges: string[];
}

export interface Review {
  id: string;
  userId: string;
  userName: string;
  rating: number;
  comment: string;
  date: string;
}

export interface RouteModel {
  id: string;
  title: string;
  slug: string;
  description: string;
  category: CategoryType;
  price: number;
  currency: string;
  rating: number;
  reviews: number;
  difficulty: 'Fácil' | 'Moderado' | 'Difícil' | 'Experto';
  distanceKm: number;
  durationMin: number;
  thumbnail: string;
  location: GeoLocation;
  creator: Creator;
  points: RoutePoint[];
  tags: string[];
  status?: 'draft' | 'published'; // Added status field
}

export interface UserState {
  currentLocation: GeoLocation;
  cart: RouteModel[];
  purchasedRoutes: string[]; // IDs
  favorites: string[]; // IDs
}